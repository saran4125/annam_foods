<?php
declare(strict_types=1);
namespace Annam;

final class Checkout {
    public function __construct(private Store $store) {}
    public function details(array $input): array {
        $result=[];foreach(['name'=>120,'email'=>254,'line1'=>200,'line2'=>200,'city'=>80,'landmark'=>120,'state'=>100,'country'=>80] as $key=>$limit){$value=$input[$key]??'';if(!is_string($value)||mb_strlen(trim($value))>$limit)throw new HttpError(422,'Check '.$key.'.');$result[$key]=trim($value);}
        foreach(['name','line1','city'] as $key)if($result[$key]==='')throw new HttpError(422,'Enter '.$key.'.');
        if($result['email']!==''&&!filter_var($result['email'],FILTER_VALIDATE_EMAIL))throw new HttpError(422,'Enter a valid email address.');
        $result['country']=$result['country']?:'India';$result['state']=$result['state']?:'Tamil Nadu';$result['phone']=Orders::phone((string)($input['phone']??''),$result['country']);$result['pincode']=trim((string)($input['pincode']??''));
        if((strcasecmp($result['country'],'India')===0&&!preg_match('/^[1-9][0-9]{5}$/D',$result['pincode']))||strlen($result['pincode'])>20)throw new HttpError(422,'Enter an exact six-digit pincode.');
        $result['zone_id']=empty($input['zone_id'])?null:(int)$input['zone_id'];$result['payment_method']=(string)($input['payment_method']??'online');
        if(!isset($this->choices()[$result['payment_method']]))throw new HttpError(422,'Choose an available payment method.');return $result;
    }
    public function choices(): array {
        $result=[];$test=!empty($this->store->config['features']['checkout_test_mode']);
        $mode=$test?'test':'live';
        if(getenv('PAYMENTS_ENABLED')==='1'&&$this->store->db->one('SELECT id FROM payments_razorpayconnection WHERE tenant_id=? AND enabled AND mode=?',[$this->store->id(),$mode]))$result['online']=$test?'TEST online payment (simulated)':'Pay online with Razorpay';
        if($test)$result['manual']='TEST / temporary manual payment';
        return $result;
    }
    public function quote(array $cart,array $details): array {
        if(!($this->store->config['features']['website_ordering']??true))throw new HttpError(422,'Website ordering is currently closed.');
        $live=Cart::quote($this->store,$cart);if(!$live['lines'])throw new HttpError(422,'Add items before checking out.');
        $lines=[];foreach($live['lines'] as $line){$snapshot=Pricing::line($line['item'],$line['quantity'],Money::decimal($line['unit']));$snapshot['meal_key']=$line['meal_key'];$snapshot['meal_label']=$line['meal_label'];$lines[]=$snapshot;}
        $slot=null;$date=null;
        if($cart['kind']==='courier'){
            if(!($this->store->config['features']['snacks_courier']??false))throw new HttpError(422,'Shop ordering is unavailable.');
            $delivery=(new Delivery($this->store))->snacks($details,$live['subtotal']);$zone=$delivery['zone'];$fee=$delivery['fee'];
        }else{
            if(!in_array($cart['date'],[date('Y-m-d'),date('Y-m-d',strtotime('+1 day'))],true))throw new HttpError(422,'Choose today or tomorrow for meal delivery.');
            $slot=$this->store->slot((int)$cart['slot_id']);$date=$cart['date'];if(in_array($date,$this->store->config['checkout_settings']['closed_dates']??[],true))throw new HttpError(422,'Meals are closed on this date.');$closed=$this->store->config['kitchen_closed_window']??[];
            if(isset($closed['from'],$closed['to'])&&$date>=$closed['from']&&$date<=$closed['to'])throw new HttpError(422,'The kitchen is closed on this date.');
            $delivery=(new Delivery($this->store))->local($details['pincode'],$live['meal_keys'],$live['subtotal'],$details['zone_id']??null);$zone=$delivery['zone'];$fee=$delivery['fee'];
        }
        if(count($live['meal_keys'])>1)$slot=null;
        $quote=Pricing::totals($lines,$fee,$this->store->profile())+['zone'=>$zone,'kind'=>$cart['kind'],'slot'=>$slot,'date'=>$date,'courier_deferred'=>$delivery['deferred']??false];
        $connection=$details['payment_method']==='online'?$this->store->db->one('SELECT id,key_id,mode FROM payments_razorpayconnection WHERE tenant_id=? AND enabled AND mode=?',[$this->store->id(),!empty($this->store->config['features']['checkout_test_mode'])?'test':'live']):null;
        if($details['payment_method']==='online'&&!$connection)throw new HttpError(422,'Online payments are unavailable.');
        $quote['connection']=$connection;return $quote;
    }
    public static function fingerprint(array $quote,array $details): string { return hash('sha256',json_encode([$quote,$details],JSON_THROW_ON_ERROR)); }
    public function review(array $input): array {
        $this->store->reload();$details=$this->details($input);$cart=$_SESSION['cart']??[];$quote=$this->quote($cart,$details);
        $reference=str_replace('-','',Store::uuid());$this->browser();
        $_SESSION['checkout_reviews'][$reference]=['details'=>$details,'cart'=>$cart,'fingerprint'=>self::fingerprint($quote,$details),'expires'=>time()+1800];
        foreach($_SESSION['checkout_reviews'] as $key=>$record)if($record['expires']<time())unset($_SESSION['checkout_reviews'][$key]);
        if(count($_SESSION['checkout_reviews'])>20)$_SESSION['checkout_reviews']=array_slice($_SESSION['checkout_reviews'],-20,null,true);
        return ['reference'=>$reference,'quote'=>$quote,'details'=>$details];
    }
    public function place(string $reference): array {
        if(!preg_match('/^[a-f0-9]{32}$/D',$reference)||!$this->browser(false))throw new HttpError(422,'The checkout review expired.');
        $external='web:'.$_SESSION['checkout_browser'].':'.$reference;
        return $this->store->db->transaction(function()use($reference,$external){
            $this->store->lock();$existing=$this->store->db->one('SELECT id FROM orders_order WHERE tenant_id=? AND external_ref=?',[$this->store->id(),$external]);
            if($existing)return (new Orders($this->store))->get((int)$existing['id']);
            $review=$_SESSION['checkout_reviews'][$reference]??null;if(!$review||$review['expires']<time())throw new HttpError(422,'Your order review expired. Review the cart again.');
            $this->store->reload();$details=$this->details($review['details']);
            foreach(array_keys($review['cart']['lines']) as $id)$this->store->db->one('SELECT id FROM catalog_menuitem WHERE tenant_id=? AND id=? FOR UPDATE',[$this->store->id(),Cart::itemId($id)]);
            $quote=$this->quote($_SESSION['cart']??[], $details);
            if(!hash_equals($review['fingerprint'],self::fingerprint($quote,$details)))throw new HttpError(409,'Your cart, prices or delivery settings changed. Please review the total again.');
            $order=(new Orders($this->store))->create($quote,$details,$external);
            if($details['payment_method']==='online') (new Payments($this->store))->intent($order,$quote['connection']);
            $_SESSION['recent_order'][$this->store->id()]=$reference;unset($_SESSION['cart']);return $order;
        });
    }
    public function browser(bool $create=true): ?string {
        $name='annam_guest_'.$this->store->id();$key=$_SESSION['checkout_browser']??null;
        if(!$key){
            $cookie=$_COOKIE[$name]??'';$parts=is_string($cookie)?explode('.',$cookie):[];
            if(count($parts)===3&&preg_match('/^[a-f0-9]{32}$/D',$parts[0])&&ctype_digit($parts[1])&&(int)$parts[1]>time()&&(int)$parts[1]<=time()+30*86400&&hash_equals(hash_hmac('sha256',$name.':'.$parts[0].'.'.$parts[1],getenv('APP_SECRET')?:''),$parts[2]))$key=$parts[0];
        }
        if(!$key&&$create)$key=bin2hex(random_bytes(16));
        if($key){
            $_SESSION['checkout_browser']=$key;
            if(PHP_SAPI!=='cli'){$expires=time()+30*86400;$value=$key.'.'.$expires;$value.='.'.hash_hmac('sha256',$name.':'.$value,getenv('APP_SECRET')?:'');setcookie($name,$value,['expires'=>$expires,'path'=>'/','secure'=>str_starts_with(getenv('APP_URL')?:'','https://'),'httponly'=>true,'samesite'=>'Lax']);}
        }
        return $key;
    }
    public function recent(): ?string {
        $browser=$this->browser(false);if(!$browser)return null;
        $row=$this->store->db->one('SELECT external_ref FROM orders_order WHERE tenant_id=? AND external_ref LIKE ? ORDER BY placed_at DESC,id DESC LIMIT 1',[$this->store->id(),'web:'.$browser.':%']);
        if(!$row)return null;$reference=substr($row['external_ref'],strrpos($row['external_ref'],':')+1);
        return preg_match('/^[a-f0-9]{32}$/D',$reference)?$reference:null;
    }
    public function guest(string $reference): array {
        $ref=str_replace('-','',$reference);if(!preg_match('/^[a-f0-9]{32}$/D',$ref))throw new HttpError(404,'Order not found.');
        $keys=array_filter([$this->browser(false),LegacySession::browser($this->store->id())]);
        foreach($keys as $key){$row=$this->store->db->one('SELECT id FROM orders_order WHERE tenant_id=? AND external_ref=?',[$this->store->id(),'web:'.$key.':'.$ref]);if($row)return (new Orders($this->store))->get((int)$row['id']);}
        throw new HttpError(404,'Order not found for this browser.');
    }
}
