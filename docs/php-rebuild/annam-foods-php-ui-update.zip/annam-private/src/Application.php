<?php
declare(strict_types=1);
namespace Annam;

final class Application {
    private Database $db;
    private Store $store;
    private ?array $user = null;
    public static function run(): void {
        try { (new self())->handle(); }
        catch (HttpError $error) { http_response_code($error->status); self::error($error->getMessage()); }
        catch (ProviderError $error) { http_response_code(503); self::error($error->getMessage()); }
        catch (\InvalidArgumentException $error) { http_response_code(422); self::error($error->getMessage()); }
        catch (\Throwable $error) {
            error_log('Request failed: '.get_class($error).' code '.(string)$error->getCode()); http_response_code(503);
            self::error('The website could not complete this request. Check the private server log and environment settings.');
        }
    }
    private static function error(string $message): void {
        $status=http_response_code()?:500;$expired=str_contains(strtolower($message),'session expired');
        $path=parse_url($_SERVER['REQUEST_URI']??'/',PHP_URL_PATH)?:'/';
        $management=str_starts_with($path,'/manage/');$billing=str_starts_with($path,'/billing/');
        $recovery=$management?'/manage/login/':($billing?'/billing/login/':(str_starts_with($path,'/checkout')?'/checkout/':'/'));
        $logo=ANNAM_ROOT.'/resources/public-files/brand/annam-bill-logo.png';
        $logoData=is_readable($logo)?'data:image/png;base64,'.base64_encode(file_get_contents($logo)):'';
        header('Content-Type: text/html; charset=utf-8');header('Cache-Control: private, no-store');
        require ANNAM_ROOT.'/views/error.php';
    }
    private function handle(): void {
        if(Installation::pending()){Installation::handle();return;}
        if(parse_url($_SERVER['REQUEST_URI'],PHP_URL_PATH)==='/setup/'&&Installation::config()){redirect('/manage/login/');}
        if (!in_array(getenv('APP_ENV') ?: 'local', ['local', 'preview','production'], true)) throw new HttpError(503, 'Invalid application environment.');
        if(getenv('APP_ENV')==='production'&&parse_url(getenv('APP_URL')?:'',PHP_URL_SCHEME)!=='https')throw new HttpError(503,'Production requires an HTTPS website URL.');
        $expected = parse_url(getenv('APP_URL') ?: 'http://127.0.0.1:8091', PHP_URL_HOST);
        $rawHost = $_SERVER['HTTP_HOST'] ?? '';
        if (!preg_match('/^[a-zA-Z0-9.:[\]-]+$/D', $rawHost)) throw new HttpError(404, 'Unknown store hostname.');
        $host = parse_url('http://' . $rawHost, PHP_URL_HOST);
        if (!$host || strtolower($host) !== strtolower($expected)) throw new HttpError(404, 'Unknown store hostname.');
        Security::start();
        $this->db = new Database();
        $path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
        $method = $_SERVER['REQUEST_METHOD'];
        // Accept the management entry addresses customers type without a slash.
        if ($method === 'GET' && in_array($path, ['/manage', '/manage/login', '/billing', '/billing/login'], true)) {
            $query = parse_url($_SERVER['REQUEST_URI'], PHP_URL_QUERY);
            redirect($path . '/' . ($query ? '?' . $query : ''));
        }
        if ($path === '/healthz') { $this->db->one('SELECT 1'); header('Content-Type: application/json'); $health=['status'=>'ok','application'=>'annam-php']; $revision=getenv('RENDER_GIT_COMMIT')?:''; if(preg_match('/^[a-f0-9]{40}$/D',$revision))$health['revision']=$revision; echo json_encode($health); return; }
        Inventory::ensure($this->db);
        $this->store = new Store($this->db);
        if($path==='/readyz'){$pulse=$this->db->one("SELECT updated_at>CURRENT_TIMESTAMP-INTERVAL '5 minutes' AS fresh FROM operations_workerpulse WHERE tenant_id=? AND name='php-cron'",[$this->store->id()]);$ok=is_writable(Media::root())&&(getenv('REQUIRE_CRON')!=='1'||($pulse['fresh']??false));http_response_code($ok?200:503);header('Content-Type: application/json');echo json_encode(['status'=>$ok?'ready':'not_ready']);return;}
        $this->user = Security::user($this->db, $this->store);
        if(preg_match('~^/platform/assets/'.preg_quote($this->store->tenant['slug'],'~').'/([a-f0-9-]{36})/$~D',$path,$asset)){Media::asset($this->store,$asset[1],$this->user!==null);return;}
        if(str_starts_with($path,'/media/')){Media::serve(substr($path,7));return;}
        if (!in_array($method, ['GET', 'POST'], true)) throw new HttpError(405, 'Method not allowed.');
        $workflow=new Workflow($this->store,$this->user,fn($view,$data=[],$admin=false)=>$this->render($view,$data,$admin));
        if($workflow->callbacks($path,$method))return;
        if ($method === 'POST') Security::verifyCsrf();
        if(str_starts_with($path,'/billing/')){(new BillingPortal($this->store,$this->user))->handle($path,$method);return;}

        if ($path === '/manage/login/') {
            $error = '';
            if ($method === 'POST') {
                if (Security::login($this->db, $this->store, (string)($_POST['username'] ?? ''), (string)($_POST['password'] ?? ''))) redirect('/manage/');
                $error = 'The username or password is incorrect, or this account has no store access.';
            }
            $this->render('login', compact('error'), false); return;
        }
        if (str_starts_with($path, '/manage/')) {
            if (!$this->user) redirect('/manage/login/');
            $this->admin($path, $method); return;
        }
        if($workflow->publicRoute($path,$method))return;
        if ($path === '/cart/add/' && $method === 'POST') {
            $ajax=($_SERVER['HTTP_X_REQUESTED_WITH']??'')==='fetch';$before=$_SESSION['cart']??null;
            try{
                if(isset($_POST['delta']))Cart::adjust($this->store,$_POST);else Cart::add($this->store,$_POST);
                if($ajax){$quote=Cart::quote($this->store);$item=$this->store->item((int)$_POST['item_id']);$meal=$item['fulfilment']==='scheduled'?$this->store->slot((int)$_POST['slot_id'])['key']:null;$current=Cart::selection((int)$item['id'],$meal,$meal?$_POST['date']:null);header('Content-Type: application/json');header('Cache-Control: no-store');echo json_encode(['quantity'=>$current['quantity'],'count'=>array_sum($_SESSION['cart']['lines']??[]),'subtotal'=>Money::display($quote['subtotal']),'message'=>'Cart updated.']);return;}
                $_SESSION['notice']='Added to your cart.';redirect('/cart/');
            }catch(HttpError $e){if(!$ajax)throw $e;if($before===null)unset($_SESSION['cart']);else $_SESSION['cart']=$before;http_response_code($e->status);header('Content-Type: application/json');header('Cache-Control: no-store');echo json_encode(['error'=>$e->getMessage()]);return;}
        }
        if($path==='/cart/update/'&&$method==='POST'){$quantity=filter_var($_POST['quantity']??'',FILTER_VALIDATE_INT);if($quantity===false)throw new HttpError(422,'Enter a whole quantity.');Cart::set($this->store,(string)($_POST['item_id']??''),$quantity);redirect('/cart/');}
        if ($path === '/cart/clear/' && $method === 'POST') { unset($_SESSION['cart']); redirect('/cart/'); }
        if ($path === '/cart/remove/' && $method === 'POST') { unset($_SESSION['cart']['lines'][(string)($_POST['item_id'] ?? '')]); redirect('/cart/'); }
        if ($method !== 'GET' && $path !== '/cart/') throw new HttpError(405, 'Method not allowed.');
        if ($path === '/') {
            $slots = $this->store->slots(); $date = date('Y-m-d'); $menus = [];
            foreach ($slots as $slot) $menus[] = ['slot' => $slot, 'items' => $this->store->menu($date, (int)$slot['id'])];
            $products=array_values(array_filter($this->store->items('courier'),fn($i)=>$i['active']&&($i['in_stock']??true)&&(!$i['quantity_tracked']||$i['stock_quantity']>0)));usort($products,fn($a,$b)=>[!in_array('featured',json_decode($a['tags'],true),true),$a['sort'],-$a['sort_priority'],$a['name'],$a['id']]<=>[!in_array('featured',json_decode($b['tags'],true),true),$b['sort'],-$b['sort_priority'],$b['name'],$b['id']]);$products=array_slice($products,0,12);
            $banners = $this->db->rows('SELECT * FROM content_banner WHERE tenant_id=? AND active ORDER BY sort,id LIMIT 12', [$this->store->id()]);
            $this->render('home', compact('menus', 'products', 'banners', 'date')); return;
        }
        if ($path === '/menu/') {
            $date = Store::date((string)($_GET['date'] ?? date('Y-m-d'))); $menus = [];
            foreach ($this->store->slots() as $slot) $menus[] = ['slot' => $slot, 'items' => $this->store->menu($date, (int)$slot['id'], true)];
            $this->render('menu', compact('menus', 'date')); return;
        }
        if (preg_match('~^/shop/(?:([a-z0-9-]+)/)?$~', $path, $match)) {
            $category = null;
            if (!empty($match[1])) {
                $category = $this->db->one('SELECT * FROM catalog_menucategory WHERE tenant_id=? AND slug=? AND active', [$this->store->id(), $match[1]]) ?? throw new HttpError(404, 'Category not found.');
            }
            $query = trim((string)($_GET['q'] ?? ''));
            $result=$this->store->pageItems('courier',$query,$category&&$category['slug']!=='shop'?(int)$category['id']:null,(int)($_GET['page']??1),36,['active'=>true,'in_stock'=>true],'',(string)($_GET['sort']??'featured'));$products=$result['records'];$total=$result['total'];$page=$result['page'];$this->render('shop',compact('products','category','query','total','page')); return;
        }
        if (preg_match('~^/item/(\d+)/$~', $path, $match)) {
            $item = $this->store->item((int)$match[1]);
            if (!$item['active']||!($item['in_stock']??true)) throw new HttpError(404, 'Item not available.');
            $this->render('item', compact('item')); return;
        }
        if ($path === '/cart/') {
            try{$quote=Cart::quote($this->store);}catch(HttpError $exception){$this->render('cart-stale',['error'=>$exception->getMessage()]);return;} $delivery = null; $error = '';
            if ($quote['lines'] && ($method === 'POST' || ($quote['cart']['kind']==='scheduled' && !empty($_SESSION['cart']['pincode'])))) {
                try {
                    $subtotal = $quote['subtotal'];
                    $pin=trim((string)($_POST['pincode']??($_SESSION['cart']['pincode']??'')));$areaValue=$method==='POST'?($_POST['area_id']??null):($_SESSION['cart']['zone_id']??null);$area=$areaValue?(int)$areaValue:null;
                    if($quote['cart']['kind']==='scheduled')$delivery=(new Delivery($this->store))->local($pin,$quote['meal_keys'],$subtotal,$area);
                    else $delivery=(new Delivery($this->store))->snacks(['pincode'=>$pin,'zone_id'=>$area,'city'=>$_POST['city']??'','country'=>$_POST['country']??'India'],$subtotal);
                    $_SESSION['cart']['pincode']=$pin;$_SESSION['cart']['zone_id']=$area;
                } catch (HttpError $e) { $error = $e->getMessage(); }
            }
            $areas = $this->db->rows('SELECT id,area_name,pincode FROM delivery_deliveryzone WHERE tenant_id=? AND active ORDER BY area_name', [$this->store->id()]);
            $this->render('cart', compact('quote', 'delivery', 'error', 'areas')); return;
        }
        if ($path === '/about/' || preg_match('~^/p/([a-z0-9-]+)/$~', $path, $match)) {
            $slug = $path === '/about/' ? 'about' : $match[1];
            $page = $this->db->one('SELECT * FROM content_page WHERE tenant_id=? AND published AND slug=?', [$this->store->id(), $slug]) ?? throw new HttpError(404, 'Page not found.');
            $this->render($path==='/about/'?'about':'page', compact('page')); return;
        }
        throw new HttpError(404, 'Page not found.');
    }
    private function admin(string $path, string $method): void {
        if((new ParityRoutes($this->store,$this->user,fn($view,$data=[],$admin=true)=>$this->render($view,$data,$admin)))->admin($path,$method))return;
        if((new Workflow($this->store,$this->user,fn($view,$data=[],$admin=false)=>$this->render($view,$data,$admin)))->admin($path,$method))return;
        $resources = new Resources($this->store);
        if ($path === '/manage/logout/' && $method === 'POST') { $_SESSION = []; session_regenerate_id(true); redirect('/manage/login/'); }
        if ($path === '/manage/') {
            $items = $this->store->items(); $date = date('Y-m-d'); $menus = [];
            foreach ($this->store->slots() as $slot) $menus[] = ['slot' => $slot, 'items' => $this->store->menu($date, (int)$slot['id'])];
            $this->render('dashboard', compact('items', 'date', 'menus'), true); return;
        }
        if ($path === '/manage/dishes/menu/') {
            $slots = array_values(array_filter($this->store->slots(),fn($mealSlot)=>isset(Catalog::MEALS[$mealSlot['key']])));
            $date = Store::date((string)($_POST['date'] ?? $_GET['date'] ?? date('Y-m-d')));
            $slotId = (int)($_POST['slot_id'] ?? $_GET['slot_id'] ?? ($slots[0]['id'] ?? 0));
            $slot = $this->store->slot($slotId);
            if ($method === 'POST') {
                $this->store->saveMenu($date, $slotId, (array)($_POST['items'] ?? []), (int)($_POST['revision'] ?? -1), (array)($_POST['make_orderable'] ?? []));
                $_SESSION['notice'] = 'Menu saved for ' . $date . ' · ' . $slot['label'] . '.';
                redirect('/manage/dishes/menu/?date=' . $date . '&slot_id=' . $slotId);
            }
            $entries = $this->store->menu($date, $slotId, true);
            $selected = array_column(array_filter($entries, fn($i) => $i['available'] && ($i['in_stock'] ?? true)), 'id');
            $items = array_values(array_filter($this->store->items('scheduled'),fn($item)=>in_array($slot['key'],(new Catalog($this->store))->meals($item),true)||in_array($item['id'],$selected))); $revision = $this->store->menuRevision($date, $slotId);
            $this->render('daily-menu', compact('date', 'slots', 'slot', 'slotId', 'selected', 'items', 'revision'), true); return;
        }
        if ($path === '/manage/settings/') {
            Settings::owner($this->user);
            if ($method === 'POST') {
                (new Settings($this->store))->identity($_POST,$_FILES);
                $_SESSION['notice']='Store settings saved.';redirect('/manage/settings/');
            }
            $this->render('settings', [], true); return;
        }
        if (preg_match('~^/manage/([a-z-]+)/(new|\d+)/(toggle|archive)/$~', $path, $match)) {
            if ($method !== 'POST') throw new HttpError(405, 'Use the action button.');
            if ($match[3] === 'toggle') $resources->toggle($match[1], (int)$match[2]);
            else $resources->removeFromSale($match[1], (int)$match[2]);
            redirect('/manage/' . $match[1] . '/');
        }
        if (preg_match('~^/manage/([a-z-]+)/(new|\d+)/$~', $path, $match)) {
            $key = $match[1]; $spec = Resources::definition($key); $id = $match[2] === 'new' ? null : (int)$match[2];
            $record = $id ? $resources->get($key, $id) : ['active' => true, 'is_veg' => true, 'sort' => 0, 'price' => '0', 'delivery_fee' => '0', 'min_order' => '0', 'fulfilment' => $_GET['kind'] ?? 'scheduled'];
            $form_error='';
            if ($method === 'POST') {
                try{$resources->save($key, $id, $_POST, $_FILES); $_SESSION['notice'] = 'Saved successfully.'; redirect('/manage/' . $key . '/'.($key==='categories'?'?category_view=custom':''));}
                catch(HttpError|\InvalidArgumentException $error){if($error instanceof HttpError&&$error->status!==422)throw $error;$form_error=$error->getMessage();http_response_code(422);$record=array_replace($record,$_POST);}
            }
            $this->render('resource-edit', compact('key', 'spec', 'id', 'record','form_error'), true); return;
        }
        if (preg_match('~^/manage/([a-z-]+)/$~', $path, $match) && isset(Resources::DEFINITIONS[$match[1]])) {
            $key = $match[1]; $spec = Resources::definition($key); $records = $resources->list($key);
            $kind = $_GET['kind'] ?? 'scheduled';
            $meal=(string)($_GET['meal']??'');$mealCounts=[];
            if ($key === 'dishes') {
                $records=array_values(array_filter($records,fn($row)=>$row['fulfilment']===$kind));
                if($kind==='scheduled'){
                    $members=[];foreach($this->store->slots() as $slot){$ids=array_column($this->db->rows('SELECT DISTINCT item_id FROM catalog_menuschedule WHERE tenant_id=? AND slot_id=?',[$this->store->id(),$slot['id']]),'item_id');$members[$slot['key']]=$ids;$mealCounts[$slot['key']]=count(array_filter($records,fn($r)=>in_array($r['id'],$ids)));}
                    $assigned=array_unique(array_merge([], ...array_values($members)));$mealCounts['unassigned']=count(array_filter($records,fn($r)=>!in_array($r['id'],$assigned)));
                    if($meal==='unassigned')$records=array_values(array_filter($records,fn($r)=>!in_array($r['id'],$assigned)));elseif(isset($members[$meal]))$records=array_values(array_filter($records,fn($r)=>in_array($r['id'],$members[$meal])));
                }
            }
            $query = trim((string)($_GET['q'] ?? ''));
            if ($query) $records = array_values(array_filter($records, fn($r) => stripos(implode(' ', array_filter($r, 'is_scalar')), $query) !== false));
            $this->render('resource-list', compact('key', 'spec', 'records', 'kind', 'query','meal','mealCounts'), true); return;
        }
        throw new HttpError(404, 'This management page has not yet been migrated to the PHP preview.');
    }
    private function render(string $view, array $data = [], ?bool $admin = false): void {
        $store = $this->store; $website=new Content($store); $user = $this->user; $path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
        $notice = $_SESSION['notice'] ?? ''; unset($_SESSION['notice']);
        extract($data, EXTR_SKIP);
        ob_start(); require ANNAM_ROOT . '/views/' . $view . '.php'; $content = ob_get_clean();
        if ($view === 'login') { echo $content; return; }
        require ANNAM_ROOT . '/views/' . ($admin ? 'admin-layout' : 'store-layout') . '.php';
    }
}
