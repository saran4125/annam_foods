<?php
declare(strict_types=1);
require dirname(__DIR__) . '/src/bootstrap.php';
use Annam\{Database,Store,Resources,Money,Cart,Security,HttpError};

if (PHP_SAPI !== 'cli') exit(1);
if (!preg_match('/(?:dbname=|sqlite:)[^;]*(?:preview|test)[^;]*(?:;|$)/i', getenv('DATABASE_DSN') ?: '')) {
    fwrite(STDERR, "Tests require a disposable database whose name includes preview or test.\n"); exit(1);
}
$pdo = new PDO(getenv('DATABASE_DSN'), getenv('DATABASE_USER'), getenv('DATABASE_PASSWORD'), [PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION]);
$db = new Database($pdo);
$pdo->beginTransaction();
$passed = 0;
function check(bool $condition, string $message): void { if (!$condition) throw new RuntimeException($message); }
function expectError(callable $operation, int $status): void {
    try { $operation(); } catch (HttpError $error) { check($error->status===$status, 'Unexpected error status'); return; }
    throw new RuntimeException('Expected operation to fail');
}
function insert(Database $db, string $table, array $values): int {
    $row=$db->one('INSERT INTO '.$table.'('.implode(',',array_map(fn($k)=>'"'.$k.'"',array_keys($values))).') VALUES('.implode(',',array_fill(0,count($values),'?')).') RETURNING id',array_values($values));
    return (int)$row['id'];
}
function test(string $name, callable $run): void {
    global $passed; $run(); $passed++; echo "PASS $name\n";
}
try {
    $suffix=bin2hex(random_bytes(6));
    $tenant=insert($db,'tenancy_tenant',['slug'=>'php-test-'.$suffix,'name'=>'Test kitchen','primary_domain'=>'','status'=>'active','created_at'=>date('c')]);
    $other=insert($db,'tenancy_tenant',['slug'=>'other-'.$suffix,'name'=>'Other kitchen','primary_domain'=>'','status'=>'active','created_at'=>date('c')]);
    $template=$db->one('SELECT * FROM tenancy_tenantconfig ORDER BY id LIMIT 1');
    unset($template['id']);
    foreach ([$tenant,$other] as $id) {
        $template['tenant_id']=$id;
        foreach ($template as $key=>$value) if ($value===true||$value===false) $template[$key]=$value;
        $template['features']=json_encode(['snacks_courier'=>true,'website_ordering'=>true,'manual_payments'=>true,'checkout_test_mode'=>true]);$template['theme']='{}';$template['checkout_settings']='{}';$template['storefront_design']='{}';$template['home_sections']='[]';
        insert($db,'tenancy_tenantconfig',$template);
    }
    putenv('STORE_SLUG=php-test-'.$suffix); $store=new Store($db); $resources=new Resources($store);
    $slot=insert($db,'catalog_slot',['tenant_id'=>$tenant,'key'=>'lunch','label'=>'Lunch','order_cutoff'=>'23:59:59','order_days_before'=>1,'order_opens_at'=>'00:00:00','delivery_from'=>null,'delivery_to'=>null,'sort'=>0,'active'=>true]);
    $otherSlot=insert($db,'catalog_slot',['tenant_id'=>$other,'key'=>'lunch','label'=>'Lunch','order_cutoff'=>'23:59:59','order_days_before'=>1,'order_opens_at'=>'00:00:00','delivery_from'=>null,'delivery_to'=>null,'sort'=>0,'active'=>true]);
    $item=$resources->save('dishes',null,['name'=>'Test lunch','fulfilment'=>'scheduled','price'=>'110.25','active'=>'1','is_veg'=>'1','sort'=>'0']);
    $item2=$resources->save('dishes',null,['name'=>'Other lunch','fulfilment'=>'scheduled','price'=>'85.50','active'=>'1','is_veg'=>'1','sort'=>'0']);
    $shop=$resources->save('dishes',null,['name'=>'Test podi','fulfilment'=>'courier','price'=>'150.10','active'=>'1','is_veg'=>'1','sort'=>'0']);
    putenv('STORE_SLUG=other-'.$suffix);$otherStore=new Store($db);
    $otherItem=(new Resources($otherStore))->save('dishes',null,['name'=>'Private dish','fulfilment'=>'scheduled','price'=>'999','active'=>'1','sort'=>'0']);
    putenv('STORE_SLUG=php-test-'.$suffix);
    $tomorrow=date('Y-m-d',strtotime('+1 day'));$after=date('Y-m-d',strtotime('+2 days'));
    $weekday=(int)(new DateTimeImmutable($tomorrow))->format('N')-1;
    insert($db,'catalog_menuschedule',['tenant_id'=>$tenant,'item_id'=>$item,'slot_id'=>$slot,'mode'=>'weekday','on_date'=>null,'weekday'=>$weekday,'available'=>true,'qty_limit'=>20,'qty_sold'=>2,'price_override'=>'100.50']);

    test('decimal prices are exact and never rounded through floating point',function(){
        check(Money::parse('0.10')+Money::parse('0.20')===30,'Decimal addition');
        check(Money::decimal(11025)==='110.25','Decimal output');
        foreach (['-1','1.001','NaN','1e3'] as $bad) { try { Money::parse($bad); throw new RuntimeException('Bad amount accepted'); } catch (InvalidArgumentException $expected) {} }
    });
    test('Django PBKDF2 passwords remain compatible',function(){
        $hash='pbkdf2_sha256$1000$test-salt$'.base64_encode(hash_pbkdf2('sha256','valid-password','test-salt',1000,32,true));
        check(Security::verifyPassword('valid-password',$hash),'Django password failed');
        check(!Security::verifyPassword('invalid',$hash),'Invalid password accepted');
        check(Security::verifyPassword('valid',password_hash('valid',PASSWORD_DEFAULT)),'PHP password failed');
    });
    test('store scopes apply to items, edits and meal slots',function()use($store,$resources,$otherItem,$otherSlot){
        expectError(fn()=>$store->item($otherItem),404);
        expectError(fn()=>$store->slot($otherSlot),404);
        expectError(fn()=>$resources->toggle('dishes',$otherItem),404);$page=$store->pageItems('','Test',null,1,1,['active'=>true,'in_stock'=>true]);check($page['total']===2&&count($page['records'])===1,'SQL paging/count filters or tenant scope failed');
    });
    test('date validation rejects nonexistent calendar dates',function(){expectError(fn()=>Store::date('2026-02-31'),422);});
    test('weekly prices resolve before a date has been reviewed',function()use($store,$tomorrow,$slot){
        $menu=$store->menu($tomorrow,$slot);check(count($menu)===1&&$menu[0]['effective_price']==='100.50','Weekly fallback incorrect');
    });
    test('a saved empty menu suppresses the weekly fallback',function()use($store,$tomorrow,$slot){
        $store->saveMenu($tomorrow,$slot,[],0);check($store->menu($tomorrow,$slot)===[],'Weekly rows reappeared');
    });
    test('stale menu revisions are refused without changing the menu',function()use($store,$tomorrow,$slot,$item){
        expectError(fn()=>$store->saveMenu($tomorrow,$slot,[$item],0),409);check($store->menu($tomorrow,$slot)===[],'Conflict overwrote menu');
    });
    test('saving a day does not change another day or stock counters',function()use($store,$db,$tomorrow,$after,$slot,$item,$item2){
        $store->saveMenu($tomorrow,$slot,[$item],1);$store->saveMenu($after,$slot,[$item2],0);
        $db->rows('UPDATE catalog_menuschedule SET qty_sold=3,qty_limit=4 WHERE tenant_id=? AND item_id=? AND on_date=?',[$store->id(),$item,$tomorrow]);
        $store->saveMenu($tomorrow,$slot,[],2);$store->saveMenu($tomorrow,$slot,[$item],3);
        $entry=$store->menu($tomorrow,$slot)[0];check((int)$entry['qty_sold']===3,'Counter reset');
        check((int)$store->menu($after,$slot)[0]['id']===$item2,'Other date changed');
    });
    test('forged client prices are ignored and stock limits are checked',function()use($store,$tomorrow,$slot,$item){
        $_SESSION=[];Cart::add($store,['item_id'=>$item,'quantity'=>1,'date'=>$tomorrow,'slot_id'=>$slot,'price'=>'0.01']);
        check(Cart::quote($store)['subtotal']===10050,'Server menu price override was not preserved');
        expectError(fn()=>Cart::add($store,['item_id'=>$item,'quantity'=>1,'date'=>$tomorrow,'slot_id'=>$slot]),422);
    });
    test('Snacks can be added to a meals order',function()use($store,$shop){Cart::add($store,['item_id'=>$shop,'quantity'=>1]);check(in_array('snacks',Cart::keys($_SESSION['cart']),true),'Snacks missing');unset($_SESSION['cart']);});
    test('delivery minimum excludes the delivery charge',function()use($resources,$store){
        $resources->save('zones',null,['area_name'=>'Perambur','pincode'=>'600011','delivery_fee'=>'100','min_order'=>'320','slot_keys'=>['lunch'],'active'=>'1']);
        expectError(fn()=>$store->zoneQuote('600011','lunch',25000),422);
        $quote=$store->zoneQuote('600011','lunch',32000);check($quote['fee']===10000&&$quote['minimum']===32000,'Wrong fee or minimum');
        expectError(fn()=>$store->zoneQuote('600011','breakfast',100000),422);
        expectError(fn()=>$store->zoneQuote('699999','lunch',100000),422);
    });
    test('shared pincodes require the correct area and preserve different rates',function()use($resources,$store){
        $a=$resources->save('zones',null,['area_name'=>'Ashok Nagar','pincode'=>'600083','delivery_fee'=>'40','min_order'=>'100','slot_keys'=>['lunch'],'active'=>'1']);
        $b=$resources->save('zones',null,['area_name'=>'Jaffar Khan Pet','pincode'=>'600083','delivery_fee'=>'60','min_order'=>'100','slot_keys'=>['lunch'],'active'=>'1']);
        expectError(fn()=>$store->zoneQuote('600083','lunch',20000),422);
        check($store->zoneQuote('600083','lunch',20000,$a)['fee']===4000,'Area A rate');
        check($store->zoneQuote('600083','lunch',20000,$b)['fee']===6000,'Area B rate');
    });
    test('archiving a dish preserves the schedule record',function()use($resources,$db,$store,$item){
        $resources->removeFromSale('dishes',$item);check(!$store->item($item)['active'],'Not archived');
        check((int)$db->one('SELECT count(*) AS n FROM catalog_menuschedule WHERE tenant_id=? AND item_id=?',[$store->id(),$item])['n']>0,'History deleted');
    });
    test('archived dishes stay hidden even when unavailable menu entries are requested',function()use($store,$tomorrow,$slot,$item){
        check(!in_array($item,array_column($store->menu($tomorrow,$slot,true),'id')),'Archived dish exposed');
    });
    $profileTemplate=$db->one('SELECT * FROM tenancy_billingprofile ORDER BY id LIMIT 1');unset($profileTemplate['id']);$profileTemplate['tenant_id']=$tenant;$profileTemplate['legal_name']='Test kitchen';$profileTemplate['address']='Test address';$profileTemplate['state']='Tamil Nadu';$profileTemplate['state_code']='33';$profileTemplate['fssai_no']='12345678901234';$profileTemplate['gst_mode']='unregistered';$profileTemplate['tax_rate']='0.00';$profileTemplate['round_total']=false;$profileTemplate['invoice_prefix']='PT';$profileTemplate['number_format']='{prefix}/{fy}/{seq:05d}';$profileTemplate['bill_timing']='on_payment';insert($db,'tenancy_billingprofile',$profileTemplate);
    $resources->toggle('dishes',$item);$_SESSION=[];
    $details=['name'=>'PHP test customer','phone'=>'919999999999','email'=>'','line1'=>'Test street','line2'=>'','landmark'=>'','city'=>'Chennai','pincode'=>'600011','zone_id'=>null,'payment_method'=>'manual'];
    $orders=new Annam\Orders($store);$billing=new Annam\Billing($store);$payments=new Annam\Payments($store);$checkout=new Annam\Checkout($store);
    $db->rows('UPDATE catalog_menuschedule SET qty_limit=NULL,available=TRUE,price_override=NULL WHERE tenant_id=? AND item_id=? AND on_date=?',[$tenant,$item,$tomorrow]);
    $db->rows('UPDATE catalog_menuitem SET price=? WHERE tenant_id=? AND id=?',['350.00',$tenant,$item]);
    $db->rows('UPDATE tenancy_tenantconfig SET features=? WHERE tenant_id=?',[json_encode(['website_ordering'=>true,'manual_payments'=>true,'checkout_test_mode'=>true,'snacks_courier'=>true]),$tenant]);$store->reload();
    test('checkout refuses unserved pincodes and area minimum bypasses',function()use($store,$checkout,$details,$tomorrow,$slot,$item){
        Cart::add($store,['item_id'=>$item,'quantity'=>1,'date'=>$tomorrow,'slot_id'=>$slot]);$bad=$details;$bad['pincode']='699999';expectError(fn()=>$checkout->review($bad),422);
        $bad=$details;$bad['zone_id']=999999;expectError(fn()=>$checkout->review($bad),422);
    });
    $review=$checkout->review($details);$placed=$checkout->place($review['reference']);
    test('duplicate checkout submission returns one order after the cart is cleared',function()use($checkout,$review,$placed,$db,$tenant,$item,$tomorrow){$again=$checkout->place($review['reference']);check($again['id']===$placed['id'],'Duplicate order');check(!isset($_SESSION['cart']),'Cart not cleared');check((int)$db->one('SELECT count(*) AS n FROM orders_order WHERE tenant_id=?',[$tenant])['n']===1,'Unexpected order count');check((int)$db->one("SELECT qty_sold FROM catalog_menuschedule WHERE tenant_id=? AND item_id=? AND on_date=? AND mode='date'",[$tenant,$item,$tomorrow])['qty_sold']===4,'Stock was not reserved exactly once');});
    test('guest receipts require the originating browser',function()use($checkout,$review,$placed){check($checkout->guest($review['reference'])['id']===$placed['id'],'Receipt missing');$browser=$_SESSION['checkout_browser'];unset($_SESSION['checkout_browser']);expectError(fn()=>$checkout->guest($review['reference']),404);$_SESSION['checkout_browser']=$browser;});
    test('order snapshots survive catalog edits',function()use($db,$tenant,$item,$orders,$placed){$db->rows('UPDATE catalog_menuitem SET price=? WHERE tenant_id=? AND id=?',['777.77',$tenant,$item]);check($orders->get($placed['id'])['total']===$placed['total'],'Snapshot changed');});
    test('unpaid bills cannot consume invoice numbers',function()use($billing,$placed,$db,$tenant){expectError(fn()=>$billing->issue($placed['id']),422);check((int)$db->one('SELECT count(*) AS n FROM billing_invoicesequence WHERE tenant_id=?',[$tenant])['n']===0,'Number consumed');});
    $orders->confirm($placed['id'],'tester','cash-received',true);$invoice=$billing->issue($placed['id']);
    test('paid bill issuance is idempotent and immutable',function()use($billing,$placed,$invoice,$store){check($billing->issue($placed['id'])['id']===$invoice['id'],'Duplicate bill');check($invoice['total']===$placed['total'],'Wrong bill total');check($invoice['buyer']['delivery_address']['line1']==='Test street','Address missing');try{$store->update('billing_invoice',$invoice['id'],['total'=>'1.00']);throw new RuntimeException('Bill mutable');}catch(LogicException){} });
    test('fulfilment cannot skip steps or reopen terminal orders',function()use($orders,$placed){expectError(fn()=>$orders->advance($placed['id'],'delivered','tester'),422);foreach(['confirmed','preparing','out_for_delivery','delivered'] as $state)$orders->advance($placed['id'],$state,'tester');expectError(fn()=>$orders->advance($placed['id'],'cancelled','tester'),422);});
    test('credits cannot exceed the original paid amount cumulatively',function()use($billing,$invoice){$amount=Money::parse($invoice['total']);$credit=$billing->credit($invoice['id'],$amount,'Customer refund');check($credit['total']===$invoice['total'],'Credit amount');expectError(fn()=>$billing->credit($invoice['id'],1,'Duplicate'),422);});
    test('tax arithmetic uses exact half-up paise for inclusive and exclusive rates',function(){check(Money::tax(10500,500,true)===['base'=>10000,'tax'=>500],'Inclusive tax');check(Money::tax(10010,500,false)['tax']===501,'Half-up tax');check(Annam\Billing::words(98000)==='Nine Hundred Eighty Rupees Only','Amount words');});
    putenv('SECRETS_KEY='.strtr(base64_encode(str_repeat('K',32)),'+/','-_'));
    test('encrypted credentials round-trip and tampering is refused',function(){ $token=Annam\Crypto::encrypt('private-test-token');check(Annam\Crypto::decrypt($token)==='private-test-token','Secret failed');$raw=base64_decode(strtr($token,'-_','+/'));$raw[30]=chr(ord($raw[30])^1);expectError(fn()=>Annam\Crypto::decrypt(strtr(base64_encode($raw),'+/','-_')),503);});
    $connection=$store->insert('payments_razorpayconnection',['mode'=>'test','enabled'=>true,'key_id'=>'rzp_test_fixture','_key_secret'=>Annam\Crypto::encrypt('fixture-secret'),'_webhook_secret'=>Annam\Crypto::encrypt('fixture-webhook-secret'),'updated_at'=>date('c')]);
    $quote=Annam\Pricing::totals([Annam\Pricing::line($store->item($shop),1)],0,$store->profile())+['kind'=>'courier','zone'=>[],'slot'=>null,'date'=>null];$online=$details;$online['payment_method']='online';$paidOrder=$orders->create($quote,$online,'test-online-payment');$intent=$payments->intent($paidOrder,$connection);
    $calls=[];Annam\Http::$transport=function($method,$url,$headers,$body)use(&$calls,$intent){$calls[]=$method.' '.$url;if($method==='POST'&&str_ends_with($url,'/orders'))return ['id'=>'order_fixture','amount'=>(int)$intent['amount'],'currency'=>'INR','receipt'=>'sk_'.str_replace('-','',$intent['id'])];if(str_ends_with($url,'/payments/pay_fixture'))return ['id'=>'pay_fixture','order_id'=>'order_fixture','amount'=>(int)$intent['amount'],'currency'=>'INR','status'=>'captured','captured'=>true];return ['items'=>[]];};
    test('Razorpay order creation retries reuse the original provider order',function()use($payments,$paidOrder,&$calls){$first=$payments->start($paidOrder['id']);$second=$payments->start($paidOrder['id']);check($first['provider_order_id']===$second['provider_order_id'],'Provider order changed');check(count($calls)===1,'Duplicate provider create');});
    test('browser signatures and provider amounts are both required before payment is marked paid',function()use($payments,$paidOrder,$intent,$orders){expectError(fn()=>$payments->verify($paidOrder['id'],['razorpay_payment_id'=>'pay_fixture','razorpay_order_id'=>'order_fixture','razorpay_signature'=>'bad']),403);$bad=['id'=>'pay_fixture','order_id'=>'order_fixture','amount'=>1,'currency'=>'INR','status'=>'captured','captured'=>true];expectError(fn()=>$payments->apply($intent['id'],$bad),422);check($orders->get($paidOrder['id'])['payment_status']==='pending','Invalid payment applied');$payments->verify($paidOrder['id'],['razorpay_payment_id'=>'pay_fixture','razorpay_order_id'=>'order_fixture','razorpay_signature'=>hash_hmac('sha256','order_fixture|pay_fixture','fixture-secret')]);check($orders->get($paidOrder['id'])['payment_status']==='paid','Verified payment missing');});
    test('test captures do not issue real bills and cannot be manually confirmed',function()use($billing,$paidOrder,$orders){expectError(fn()=>$billing->issue($paidOrder['id']),422);expectError(fn()=>$orders->confirm($paidOrder['id'],'tester','manual',true),422);});
    test('failed payment events do not downgrade a captured payment',function()use($payments,$intent,$orders,$paidOrder){$payments->apply($intent['id'],['id'=>'pay_failed','order_id'=>'order_fixture','amount'=>(int)$intent['amount'],'currency'=>'INR','status'=>'failed']);check($orders->get($paidOrder['id'])['payment_status']==='paid','Paid status lost');});
    test('credentials and order records cannot cross store boundaries',function()use($otherStore,$connection,$intent,$placed,$invoice){foreach([['payments_razorpayconnection',$connection['id']],['payments_paymentintent',$intent['id']],['orders_order',$placed['id']],['billing_invoice',$invoice['id']]] as [$table,$id])expectError(fn()=>$otherStore->row($table,$id),404);});
    test('uncertain provider creation is reconciled instead of submitted twice',function()use($payments,$orders,$quote,$online,$connection){$order=$orders->create($quote,$online,'test-uncertain');$intent=$payments->intent($order,$connection);$posts=0;$gets=0;Annam\Http::$transport=function($method,$url,$headers,$body)use(&$posts,&$gets,$intent){if($method==='POST'){$posts++;throw new Annam\ProviderError(true);}$gets++;return ['items'=>[]];};try{$payments->start($order['id']);}catch(Annam\ProviderError){}try{$payments->start($order['id']);}catch(Annam\ProviderError){}check($posts===1&&$gets===1,'Uncertain creation was duplicated');});
    $secretTemplate=Annam\Messaging::defaults();$secretTemplate['tenant_id']=$tenant;$secretTemplate['wa_provider']='console';$secretTemplate['wa_phone_number_id']='123456789';$secretTemplate['wa_waba_id']='987654321';$secretTemplate['wa_verify_token']='fixture-verify-token';$secretTemplate['wa_app_secret_enc']=Annam\Crypto::encrypt('fixture-app-secret');$secretTemplate['wa_sync_token_enc']=Annam\Crypto::encrypt('fixture-sync-token');$secretTemplate['n8n_receive_url']='';insert($db,'tenancy_tenantsecrets',$secretTemplate);
    $messaging=new Annam\Messaging($store);$meta=['object'=>'whatsapp_business_account','entry'=>[['id'=>'987654321','changes'=>[['field'=>'messages','value'=>['metadata'=>['phone_number_id'=>'123456789'],'contacts'=>[['wa_id'=>'919999999999','profile'=>['name'=>'Test customer']]],'messages'=>[['from'=>'919999999999','id'=>'wamid.fixture.in','timestamp'=>(string)time(),'type'=>'text','text'=>['body'=>'Hello kitchen']]]]]]]]];
    test('Meta signatures and configured phone IDs protect the inbox',function()use($messaging,$meta,$db,$tenant){$raw=json_encode($meta);expectError(fn()=>$messaging->webhook($raw,'sha256=invalid'),403);$wrong=$meta;$wrong['entry'][0]['changes'][0]['value']['metadata']['phone_number_id']='000';$wrong=json_encode($wrong);$messaging->webhook($wrong,'sha256='.hash_hmac('sha256',$wrong,'fixture-app-secret'));check((int)$db->one('SELECT count(*) AS n FROM messaging_whatsappmessage WHERE tenant_id=?',[$tenant])['n']===0,'Foreign account imported');$messaging->webhook($raw,'sha256='.hash_hmac('sha256',$raw,'fixture-app-secret'));$messaging->webhook($raw,'sha256='.hash_hmac('sha256',$raw,'fixture-app-secret'));check((int)$db->one('SELECT count(*) AS n FROM messaging_whatsappmessage WHERE tenant_id=?',[$tenant])['n']===1,'Duplicate incoming message');});
    test('queued replies are idempotent and appear in the conversation',function()use($messaging,$db,$tenant){$conversation=$db->one('SELECT * FROM messaging_whatsappconversation WHERE tenant_id=?',[$tenant]);$token=bin2hex(random_bytes(16));$_SESSION['reply_tokens'][$token]=time();$messaging->reply($conversation['id'],'Thanks for ordering',$token,'tester');$messaging->reply($conversation['id'],'Thanks for ordering',$token,'tester');check((int)$db->one('SELECT count(*) AS n FROM messaging_outboundmessage WHERE tenant_id=?',[$tenant])['n']===1,'Duplicate reply queued');check((int)$db->one("SELECT count(*) AS n FROM messaging_whatsappmessage WHERE tenant_id=? AND direction='out'",[$tenant])['n']===1,'Reply mirror missing');});
    test('closed reply windows reject free-text sends',function()use($messaging,$db,$tenant){$conversation=$db->one('SELECT * FROM messaging_whatsappconversation WHERE tenant_id=?',[$tenant]);$db->rows("UPDATE messaging_whatsappconversation SET last_inbound_at=CURRENT_TIMESTAMP-INTERVAL '25 hours' WHERE tenant_id=?",[$tenant]);$token=bin2hex(random_bytes(16));$_SESSION['reply_tokens'][$token]=time();expectError(fn()=>$messaging->reply($conversation['id'],'Too late',$token,'tester'),422);});
    test('WhatsApp payload limits are enforced before queue insertion',function()use($messaging){expectError(fn()=>$messaging->queue('919999999999',['kind'=>'text','body'=>str_repeat('x',1025)]),422);expectError(fn()=>$messaging->queue('919999999999',['kind'=>'buttons','body'=>'Choose','buttons'=>array_fill(0,4,['id'=>'x','title'=>'Choice'])]),422);expectError(fn()=>$messaging->queue('919999999999',['kind'=>'cta_url','body'=>'Choose','label'=>'Link','url'=>'javascript:alert(1)']),422);});
    test('n8n sync requires its independent bearer token',function()use($messaging,$meta){$raw=json_encode(['event'=>'meta','payload'=>$meta]);expectError(fn()=>$messaging->sync($raw,'Bearer invalid'),403);$messaging->sync($raw,'Bearer fixture-sync-token');});
    test('Markdown preserves headings and neutralizes scripts and executable links',function(){$html=Annam\Markdown::render("# Policy\n\n**Fresh food**\n\n<script>alert(1)</script>\n\n[unsafe](javascript:alert(1))");check(str_contains($html,'<h1>Policy</h1>')&&str_contains($html,'<strong>Fresh food</strong>'),'Formatting lost');check(!str_contains($html,'<script>')&&!str_contains($html,'href="javascript:'),'Executable content emitted');});
    test('media paths reject traversal and executable files',function(){foreach(['../.env','/etc/passwd','menu/evil.php','menu/%2e%2e/secret.png','menu/x.png?x'] as $path)check(Annam\Media::relative($path)===null,'Unsafe path accepted');});
    test('legacy Django guest sessions and encryption remain wire compatible',function(){
        $fixtures=json_decode(file_get_contents(__DIR__.'/compatibility.json'),true,64,JSON_THROW_ON_ERROR);check(Annam\Crypto::decrypt($fixtures['fernet'])==='legacy-secret-value','Django encrypted credential incompatible');$data=Annam\LegacySession::decode($fixtures['session'],'fixture-django-secret');check(($data['checkout.browser.1']??'')===str_repeat('a',32),'Django guest session incompatible');check(Annam\LegacySession::decode($fixtures['session'],'wrong-secret')===null,'Wrong session key accepted');
    });
    test('worker sends once and merges an early n8n callback into the queued reply',function()use($db,$tenant,$store,$messaging){
        putenv('APP_ENV=preview');$db->rows("UPDATE messaging_whatsappconversation SET last_inbound_at=CURRENT_TIMESTAMP WHERE tenant_id=?",[$tenant]);$db->rows("UPDATE tenancy_tenantsecrets SET wa_provider='n8n',n8n_send_url='https://example.com/send' WHERE tenant_id=?",[$tenant]);
        Annam\Http::$transport=function($method,$url,$headers,$body)use($messaging){$event=['event'=>'outbound','phone_number_id'=>'123456789','message'=>$body['graph'],'message_id'=>'wamid.fixture.out','timestamp'=>(string)time()];$messaging->sync(json_encode($event),'Bearer fixture-sync-token');return ['message_id'=>'wamid.fixture.out'];};
        $db->rows("UPDATE messaging_outboundmessage SET next_attempt_at=CURRENT_TIMESTAMP-INTERVAL '1 minute' WHERE tenant_id=?",[$tenant]);
        $worker=new Annam\Worker($store);$result=$worker->dispatch();check($result['sent']===1,'Queued reply not sent');check($worker->dispatch()['sent']===0,'Sent twice');check((int)$db->one("SELECT count(*) AS n FROM messaging_whatsappmessage WHERE tenant_id=? AND provider_message_id='wamid.fixture.out'",[$tenant])['n']===1,'Early callback duplicated timeline');
    });
    test('out-of-order receipts preserve read status',function()use($messaging,$meta,$db,$tenant){$event=$meta;unset($event['entry'][0]['changes'][0]['value']['messages']);foreach(['read','sent','delivered','failed'] as $state){$event['entry'][0]['changes'][0]['value']['statuses']=[['id'=>'wamid.fixture.out','status'=>$state,'recipient_id'=>'919999999999','timestamp'=>(string)time()]];$messaging->ingest($event,false);}check($db->one("SELECT status FROM messaging_whatsappmessage WHERE tenant_id=? AND provider_message_id='wamid.fixture.out'",[$tenant])['status']==='read','Receipt status downgraded');});
    test('reviewed checkout is refused if prices change before submission',function()use($store,$db,$tenant,$item,$tomorrow,$slot,$checkout,$details){$_SESSION['cart']=['kind'=>'scheduled','date'=>$tomorrow,'slot_id'=>$slot,'lines'=>[$item=>1]];$review=$checkout->review($details);$db->rows('UPDATE catalog_menuitem SET price=? WHERE tenant_id=? AND id=?',['888.88',$tenant,$item]);expectError(fn()=>$checkout->place($review['reference']),409);});
    test('disabled courier orders remain blocked without requiring a whitelist',function()use($store,$checkout,$details,$shop){Annam\Settings::validateCheckout(['courier_enabled'=>true,'courier_pincodes'=>[],'courier_fee'=>'0','courier_minimum'=>'0']);$cart=['kind'=>'courier','date'=>null,'slot_id'=>null,'lines'=>[$shop=>1]];expectError(fn()=>$checkout->quote($cart,$details),422);});
    test('live capture survives invalid billing settings and refunds create one credit only',function()use($store,$db,$tenant,$orders,$payments,$quote,$online,$billing){
        $connection=$store->insert('payments_razorpayconnection',['mode'=>'live','enabled'=>false,'key_id'=>'rzp_live_fixture','_key_secret'=>Annam\Crypto::encrypt('live-fixture-secret'),'_webhook_secret'=>Annam\Crypto::encrypt('live-fixture-webhook'),'updated_at'=>date('c')]);
        $order=$orders->create($quote,$online,'test-live-payment');$intent=$payments->intent($order,$connection);$captured=['id'=>'pay_livefixture','order_id'=>'order_livefixture','amount'=>(int)$intent['amount'],'currency'=>'INR','status'=>'captured','captured'=>true];$refundId='';
        Annam\Http::$transport=function($method,$url,$headers,$body)use($intent,$captured,&$refundId){if($method==='POST'&&str_ends_with($url,'/orders'))return ['id'=>'order_livefixture','amount'=>(int)$intent['amount'],'currency'=>'INR','receipt'=>'sk_'.str_replace('-','',$intent['id'])];if($method==='POST'&&str_ends_with($url,'/refund')){$refundId=$body['notes']['seer_refund'];return ['id'=>'rfnd_livefixture'];}if(str_contains($url,'/refunds?'))return ['items'=>[['id'=>'rfnd_livefixture','payment_id'=>'pay_livefixture','status'=>'processed','amount'=>(int)$intent['amount'],'notes'=>['seer_refund'=>$refundId]]]];if(str_ends_with($url,'/payments/pay_livefixture'))return $captured;if(str_ends_with($url,'/payments'))return ['items'=>[$captured]];return ['items'=>[]];};
        $payments->start($order['id']);$db->rows("UPDATE tenancy_billingprofile SET address='' WHERE tenant_id=?",[$tenant]);$payments->apply($intent['id'],$captured);check($orders->get($order['id'])['payment_status']==='paid','Billing error undid captured payment');check($payments->forOrder($order['id'])['bill_error']!=='','Missing billing issue marker');$db->rows("UPDATE tenancy_billingprofile SET address='Test address' WHERE tenant_id=?",[$tenant]);$invoice=$billing->issue($order['id']);
        $payments->refund($order['id'],'Customer requested cancellation','tester');check($orders->get($order['id'])['payment_status']==='refunded','Verified refund missing');$payments->reconcile($order['id']);check((int)$db->one('SELECT count(*) AS n FROM billing_invoice WHERE tenant_id=? AND original_id=?',[$tenant,$invoice['id']])['n']===1,'Duplicate credit note');
        $event=json_encode(['event'=>'refund.processed','payload'=>['refund'=>['entity'=>['payment_id'=>'pay_livefixture']]]]);$signature=hash_hmac('sha256',$event,'live-fixture-webhook');$payments->webhook('live',$event,$signature,'evt_fixture');$payments->webhook('live',$event,$signature,'evt_fixture');check((int)$db->one('SELECT count(*) AS n FROM payments_paymentevent WHERE tenant_id=? AND event_id=?',[$tenant,'evt_fixture'])['n']===1,'Webhook not deduplicated');
    });
    test('Dinner is separate and pincode restrictions use the approved customer messages',function()use($store,$resources){
        try{Annam\Delivery::combination(['breakfast','lunch','dinner']);throw new RuntimeException('Dinner combined');}catch(HttpError $e){check($e->getMessage()===Annam\Delivery::DINNER,'Wrong Dinner message');}
        $d=new Annam\Delivery($store);foreach([['600051',['lunch','dinner','snacks'],'breakfast',Annam\Delivery::BREAKFAST],['600052',['lunch','snacks'],'dinner',Annam\Delivery::BREAKFAST_DINNER],['600053',['snacks'],'lunch',Annam\Delivery::SNACKS_ONLY]] as [$pin,$keys,$meal,$message]){$resources->save('zones',null,['area_name'=>'Policy area','pincode'=>$pin,'delivery_fee'=>'60','min_order'=>'160','slot_keys'=>$keys,'active'=>'1']);check($d->restriction($pin,[$meal])===$message,'Wrong restriction');}
        $resources->save('zones',null,['area_name'=>'Combined zone','pincode'=>'600054','delivery_fee'=>'40','min_order'=>'100','slot_keys'=>['breakfast','lunch','snacks'],'active'=>'1']);check($d->local('600054',['breakfast','lunch','snacks'],50000)['fee']===4000,'Fee charged more than once');
    });
    test('tomorrow ordering follows opening days and cutoff in India time',function(){
        $slot=['active'=>true,'order_days_before'=>1,'order_opens_at'=>'10:00:00','order_cutoff'=>'15:00:00'];
        check(!Annam\Delivery::slotOpen($slot,'2026-11-03',new DateTimeImmutable('2026-11-02 09:59:59')),'Opened early');check(Annam\Delivery::slotOpen($slot,'2026-11-03',new DateTimeImmutable('2026-11-02 10:00:00')),'Tomorrow not open');check(!Annam\Delivery::slotOpen($slot,'2026-11-03',new DateTimeImmutable('2026-11-03 15:00:00')),'Cutoff ignored');
    });
    test('dated availability edits preserve counters and reject stale revisions',function()use($store,$db,$tomorrow,$slot,$item){
        $before=$db->one("SELECT qty_sold FROM catalog_menuschedule WHERE tenant_id=? AND item_id=? AND slot_id=? AND on_date=? AND mode='date'",[$store->id(),$item,$slot,$tomorrow]);$rev=$store->menuRevision($tomorrow,$slot);$store->setDayAvailability($tomorrow,$slot,$item,false,$rev);$after=$db->one("SELECT qty_sold,available FROM catalog_menuschedule WHERE tenant_id=? AND item_id=? AND slot_id=? AND on_date=? AND mode='date'",[$store->id(),$item,$slot,$tomorrow]);check($before['qty_sold']===$after['qty_sold']&&!$after['available'],'Counter reset or availability unchanged');check($store->item($item)['active'],'Date removal archived the product');expectError(fn()=>$store->setDayAvailability($tomorrow,$slot,$item,true,$rev),409);
    });
    test('category counts include stocked descendants and empty categories remain manageable',function()use($store,$resources,$shop){
        $parent=$resources->save('categories',null,['name'=>'Parity family','slug'=>'parity-family','active'=>'1']);$child=$resources->save('categories',null,['name'=>'Parity child','slug'=>'parity-child','active'=>'1']);$store->db->rows('UPDATE catalog_menucategory SET parent_id=? WHERE tenant_id=? AND id=?',[$parent,$store->id(),$child]);$store->db->rows('UPDATE catalog_menuitem SET category_id=?,in_stock=TRUE WHERE tenant_id=? AND id=?',[$child,$store->id(),$shop]);check(in_array($shop,array_column($store->items('courier','',$parent),'id')),'Descendants missing');$categories=(new Annam\ParityRoutes($store,['id'=>1],fn()=>null))->categories();$r=array_values(array_filter($categories,fn($r)=>(int)$r['id']===$parent))[0];check($r['website']===1&&$r['total']===1,'Category count mismatch');
    });
    test('phone lookup matches local and country-code forms and never another tenant',function()use($store,$otherStore,$details){
        $result=(new Annam\CustomerLookup($store))->find('9999999999');check($result['found']&&$result['details']['address']==='Test street','Latest address not filled');check((new Annam\CustomerLookup($otherStore))->find($details['phone'])['found']===false,'Customer leaked');check(Annam\CustomerLookup::stateCode('India','Tamil Nadu')==='33','State mapping');
    });
    test('shared throttles survive new requests and are tenant-scoped',function()use($store,$otherStore){Annam\Operations::limit($store,'fixture',1,60);expectError(fn()=>Annam\Operations::limit($store,'fixture',1,60),429);Annam\Operations::limit($otherStore,'fixture',1,60);});
    test('courier is deferred outside Chennai and cannot bypass a missing local zone',function()use($store,$db){$cfg=['courier_enabled'=>true,'courier_minimum'=>'100','courier_fee'=>'0','courier_pincodes'=>[],'courier_team_phone'=>'919888888888'];$db->rows('UPDATE tenancy_tenantconfig SET checkout_settings=? WHERE tenant_id=?',[json_encode($cfg),$store->id()]);$store->reload();$d=new Annam\Delivery($store);foreach([['city'=>'Coimbatore','country'=>'India','pincode'=>'641001'],['city'=>'London','country'=>'UK','pincode'=>'SW1A']] as $details){$q=$d->snacks($details,15000);check($q['deferred']&&$q['fee']===0,'Courier was charged in food total');}expectError(fn()=>$d->snacks(['city'=>'Chennai','country'=>'India','pincode'=>'600099'],15000),422);});
    test('courier notices are held offline and courier receipts do not alter the food bill',function()use($store,$orders,$shop,$details,$db,$billing){
        $d=$details;$d['city']='Coimbatore';$d['pincode']='641001';$d['country']='India';$quote=Annam\Pricing::totals([Annam\Pricing::line($store->item($shop),2)],0,$store->profile())+['kind'=>'courier','slot'=>null,'date'=>null,'zone'=>[],'courier_deferred'=>true];$o=$orders->create($quote,$d,'courier-fixture','manual','tester');$courier=new Annam\Courier($store);check($courier->get($o['id'])!==null,'Charge ledger missing');$messages=$db->rows("SELECT status FROM messaging_outboundmessage WHERE tenant_id=? AND dedupe_key LIKE ?",[$store->id(),'courier:'.$o['id'].':%']);check(count($messages)===2&&array_unique(array_column($messages,'status'))===['held'],'Offline notices not held');expectError(fn()=>$courier->dispatch($o['id'],'80','Local courier','track1','tester'),422);foreach(['confirmed','preparing','out_for_delivery'] as $state)$orders->advance($o['id'],$state,'tester');$courier->dispatch($o['id'],'80','Local courier','track1','tester');$courier->confirm($o['id'],'cash-received','tester');check($orders->get($o['id'])['total']===$o['total']&&$orders->get($o['id'])['payment_status']==='pending','Courier receipt changed food order');check($courier->get($o['id'])['paid_at']!==null,'Courier not paid');expectError(fn()=>$courier->dispatch($o['id'],'90','Local courier','track1','tester'),409);
    });
    test('reports group product quantities and sales exclude simulated payments',function()use($store,$placed){$r=(new Annam\Reports($store))->data(['start'=>date('Y-m-d').'T00:00','end'=>date('Y-m-d\TH:i:s',time()+2)]);check($r['order_count']>=1&&$r['quantity']>=1,'Report empty');$sales=(new Annam\Reports($store))->sales();check(Money::parse($sales['courier_receipts'])===8000,'Separate courier receipt missing');$g=(new Annam\Reports($store))->orderGroups([]);check(count($g['records'])>=1,'Groups empty');});

    test('online courier capture verifies evidence and test mode never settles the real receivable',function()use($store,$orders,$shop,$details,$db,$connection){
        $cfg=$store->config['checkout_settings'];$cfg['courier_online_enabled']=true;$db->rows('UPDATE tenancy_tenantconfig SET checkout_settings=? WHERE tenant_id=?',[json_encode($cfg),$store->id()]);$store->reload();$d=$details;$d['city']='Coimbatore';$d['pincode']='641001';$d['country']='India';$q=Annam\Pricing::totals([Annam\Pricing::line($store->item($shop),1)],0,$store->profile())+['kind'=>'courier','zone'=>[],'slot'=>null,'date'=>null,'courier_deferred'=>true];$o=$orders->create($q,$d,'courier-online-fixture','manual','tester');foreach(['confirmed','preparing','out_for_delivery'] as $state)$orders->advance($o['id'],$state,'tester');$courier=new Annam\Courier($store);$courier->dispatch($o['id'],'75','Courier','track-online','tester');$calls=0;$providerOrder='order_courierfixture';
        Annam\Http::$transport=function($method,$url,$headers,$body)use(&$calls,$providerOrder){if($method==='POST'){$calls++;return ['id'=>$providerOrder,'amount'=>$body['amount'],'currency'=>'INR','receipt'=>$body['receipt']];}return ['id'=>'pay_courierfixture','order_id'=>$providerOrder,'amount'=>7500,'currency'=>'INR','status'=>'captured','captured'=>true];};
        $service=new Annam\CourierPayments($store);$p=$service->start($o['id']);$service->start($o['id']);check($calls===1,'Courier provider order duplicated');$e=['razorpay_payment_id'=>'pay_courierfixture','razorpay_order_id'=>$providerOrder,'razorpay_signature'=>'bad'];expectError(fn()=>$service->verify($o['id'],$e),403);$e['razorpay_signature']=hash_hmac('sha256',$providerOrder.'|pay_courierfixture','fixture-secret');$service->verify($o['id'],$e);check(!$courier->get($o['id'])['paid_at'],'Test payment settled courier charge');check($orders->get($o['id'])['payment_status']==='pending','Courier changed food payment');$invalid=['id'=>'pay_courierfixture','order_id'=>$providerOrder,'amount'=>1,'currency'=>'INR','status'=>'captured','captured'=>true];expectError(fn()=>$service->apply($p['id'],$invalid),422);
    });


    test('breakfast lunch and dinner inherit independently until an explicit saved change',function()use($store,$db,$resources,$tenant){
        $item=$resources->save('dishes',null,['name'=>'Repeat fixture','fulfilment'=>'scheduled','price'=>'125.20','active'=>'1','in_stock'=>'1','sort'=>'0']);
        $first=date('Y-m-d',strtotime('+30 days'));$next=date('Y-m-d',strtotime('+31 days'));$later=date('Y-m-d',strtotime('+32 days'));
        foreach(['breakfast','lunch','dinner'] as $key){
            $slot=$db->one('SELECT id FROM catalog_slot WHERE tenant_id=? AND key=?',[$tenant,$key]);
            $id=$slot?(int)$slot['id']:insert($db,'catalog_slot',['tenant_id'=>$tenant,'key'=>$key,'label'=>ucfirst($key),'order_cutoff'=>'23:59:59','order_days_before'=>1,'order_opens_at'=>'00:00:00','sort'=>0,'active'=>true]);
            $store->saveMenu($first,$id,[$item],0);
            $db->rows("UPDATE catalog_menuschedule SET qty_limit=3,qty_sold=3,price_override='120.10' WHERE tenant_id=? AND slot_id=? AND on_date=? AND item_id=?",[$tenant,$id,$first,$item]);
            $menu=$store->menu($next,$id);check(count($menu)===1&&(int)$menu[0]['id']===$item,'Next-day meal missing');check($menu[0]['inherited']&&$menu[0]['qty_sold']===0&&$menu[0]['effective_price']==='120.10','Inherited portions or price incorrect');
            $db->transaction(function()use($store,$db,$next,$id,$menu){$store->lock();$schedule=$store->inventorySchedule($next,$id,$menu[0]);$db->rows('UPDATE catalog_menuschedule SET qty_sold=2 WHERE tenant_id=? AND id=?',[$store->id(),$schedule]);});
            check((int)$store->menu($next,$id)[0]['qty_sold']===2,'Target-day inventory was lost');
            $store->setDayAvailability($next,$id,$item,false,0);check($store->menu($next,$id)===[],'Dated removal failed');check($store->menu($later,$id)===[],'An explicitly empty meal reappeared');
            $source=$db->one('SELECT qty_sold FROM catalog_menuschedule WHERE tenant_id=? AND slot_id=? AND item_id=? AND on_date=?',[$tenant,$id,$item,$first]);check((int)$source['qty_sold']===3,'Previous-day portions changed');
        }
        $features=$store->config['features'];$features['carry_forward_meals']=false;$db->rows('UPDATE tenancy_tenantconfig SET features=? WHERE tenant_id=?',[json_encode($features),$tenant]);$store->reload();check(!$store->carriesForward($id),'Explicitly disabled carry-forward was ignored');
    });
    test('quantity adjustments use server validation and remove the final cart line',function()use($store,$shop){
        unset($_SESSION['cart']);Cart::adjust($store,['item_id'=>$shop,'delta'=>1]);check(Cart::selection($shop)['quantity']===1,'Add did not increment');Cart::adjust($store,['item_id'=>$shop,'delta'=>1]);check(Cart::selection($shop)['quantity']===2,'Second increment failed');Cart::adjust($store,['item_id'=>$shop,'delta'=>-1]);check(Cart::selection($shop)['quantity']===1,'Decrement failed');Cart::adjust($store,['item_id'=>$shop,'delta'=>-1]);check(Cart::selection($shop)['quantity']===0,'Last item remains');expectError(fn()=>Cart::adjust($store,['item_id'=>$shop,'delta'=>500]),422);
    });


    test('normal checkout refuses manual payment and never selects test credentials',function()use($store,$db,$tenant,$checkout,$details){
        $saved=$store->config['features'];$flags=$saved;$flags['checkout_test_mode']=false;$db->rows('UPDATE tenancy_tenantconfig SET features=? WHERE tenant_id=?',[json_encode($flags),$tenant]);$store->reload();putenv('PAYMENTS_ENABLED=1');
        check(!isset($checkout->choices()['manual']),'Manual checkout exposed');expectError(fn()=>$checkout->details($details),422);
        $live=$db->one("SELECT id FROM payments_razorpayconnection WHERE tenant_id=? AND mode='live' AND enabled",[$tenant]);check(isset($checkout->choices()['online'])===($live!==null),'Live credential selection failed');
        $db->rows('UPDATE tenancy_tenantconfig SET features=? WHERE tenant_id=?',[json_encode($saved),$tenant]);$store->reload();
    });
    test('unpaid online website orders cannot advance or be manually marked paid',function()use($orders,$quote,$online){
        $o=$orders->create($quote,$online,'receipt-unpaid');expectError(fn()=>$orders->advance($o['id'],'confirmed','tester'),422);expectError(fn()=>$orders->confirm($o['id'],'tester','fake',true),422);check($orders->get($o['id'])['payment_status']==='pending','Unpaid state changed');
    });
    test('customer PDFs use immutable snapshots and test receipts allocate no invoice numbers',function()use($store,$orders,$quote,$online,$payments,$connection,$billing,$invoice,$db,$tenant){
        $pdf=Annam\InvoicePdf::invoice($invoice);check(str_starts_with($pdf,'%PDF-'),'Invoice is not PDF');
        $o=$orders->create($quote,$online,'receipt-test-capture');$i=$payments->intent($o,$connection);$store->update('payments_paymentintent',$i['id'],['provider_order_id'=>'order_receipt']);
        $before=$db->rows('SELECT * FROM billing_invoicesequence WHERE tenant_id=?',[$tenant]);$payments->apply($i['id'],['id'=>'pay_receipt','order_id'=>'order_receipt','amount'=>(int)$i['amount'],'currency'=>'INR','status'=>'captured','captured'=>true]);
        $o=$orders->get($o['id']);check($o['status']==='confirmed','Verified capture did not confirm order');$receipt=new Annam\CustomerReceipt($store);$state=$receipt->state($o,'fixture');check($state['test']&&$state['download_url']&&!$state['invoice_url'],'Test receipt state incorrect');$pdf=$receipt->pdf($o,true);check(str_starts_with($pdf,'%PDF-'),'Test receipt not PDF');expectError(fn()=>$receipt->pdf($o,false),404);check($before===$db->rows('SELECT * FROM billing_invoicesequence WHERE tenant_id=?',[$tenant]),'Test receipt consumed invoice number');check($billing->forOrder($o['id'])===null,'Test receipt created invoice');
    });


    test('signed guest identity survives session expiry and rejects tampered browser cookies',function()use($store,$checkout,$orders,$quote,$details){
        $saved=$_SESSION;$name='annam_guest_'.$store->id();$key=bin2hex(random_bytes(16));$expires=time()+30*86400;$value=$key.'.'.$expires;$cookie=$value.'.'.hash_hmac('sha256',$name.':'.$value,getenv('APP_SECRET')?:'');
        $_SESSION=[];$_COOKIE[$name]=$cookie;$reference=bin2hex(random_bytes(16));$o=$orders->create($quote,$details,'web:'.$key.':'.$reference);
        check($checkout->recent()===$reference,'Recent order lost after session expiry');check($checkout->guest($reference)['id']===$o['id'],'Receipt unavailable after restart');
        $_SESSION=[];$_COOKIE[$name]=$cookie.'bad';check($checkout->recent()===null,'Tampered cookie exposed order');expectError(fn()=>$checkout->guest($reference),404);unset($_COOKIE[$name]);$_SESSION=$saved;
    });

    test('spotlight image uses its scoped product and preserves owner artwork',function()use($store,$resources,$otherItem,$db,$tenant){
        $id=$resources->save('dishes',null,['name'=>'Special Health Mix','fulfilment'=>'courier','price'=>'400','active'=>1,'in_stock'=>1]);$content=new Annam\Content($store);$section=['link'=>'/item/'.$id.'/','image'=>''];
        check($content->spotlightImage($section)==='/assets/health-mix.jpg','Bundled Health Mix photo missing');
        $content->images['spotlight']='/platform/assets/fixture/owner-image/';check($content->spotlightImage($section)==='/platform/assets/fixture/owner-image/','Owner artwork overwritten');unset($content->images['spotlight']);
        check($content->spotlightImage(['link'=>'/item/'.$otherItem.'/','image'=>''])==='','Other tenant product exposed');
        check($content->spotlightImage(['link'=>'/shop/','image'=>'menu/custom.jpg'])==='/media/menu/custom.jpg','Explicit section photo overwritten');
        check(is_file(ANNAM_ROOT.'/public/assets/health-mix.jpg'),'Health Mix asset not packaged');
    });


    test('collection on delivery is unpaid and idempotent until actual payment confirmation',function()use($orders,$quote,$details,$billing,$db,$tenant){
        $o=$orders->create($quote,$details,'collect-later-test','manual','tester');$orders->collectOnDelivery($o['id'],'tester');$orders->collectOnDelivery($o['id'],'tester');$o=$orders->get($o['id']);check($o['payment_mode']==='cod'&&$o['payment_status']==='cod_pending','Payment was invented');
        check((int)$db->one("SELECT COUNT(*) AS n FROM orders_orderevent WHERE tenant_id=? AND order_id=? AND note LIKE 'Payment not received.%'",[$tenant,$o['id']])['n']===1,'Duplicate collection event');
        foreach(['confirmed','preparing','out_for_delivery','delivered'] as $status)$orders->advance($o['id'],$status,'tester');check($orders->get($o['id'])['payment_status']==='cod_pending','Delivery marked payment paid');expectError(fn()=>$billing->issue($o['id']),422);
        $orders->confirm($o['id'],'tester','cash-collected',true);$bill=$billing->issue($o['id']);check($billing->issue($o['id'])['id']===$bill['id'],'Duplicate bill');expectError(fn()=>$orders->collectOnDelivery($o['id'],'tester'),422);
    });
    test('billing portal line input uses server prices and supports meal context',function()use($store,$orders,$shop){
        $token=bin2hex(random_bytes(16));$_SESSION['staff_tokens'][$token]=time();$input=['name'=>'Portal fixture','phone'=>'919999999999','token'=>$token,'channel'=>'manual','payment_method'=>'cod','booking_lines'=>[['item'=>$shop,'quantity'=>1,'meal'=>'snacks'],['item'=>$shop,'quantity'=>1,'meal'=>'snacks']],'total'=>'0.01'];$o=$orders->staff($input,'tester');check(count($o['items'])===1&&$o['items'][0]['quantity']===2&&$o['payment_status']==='cod_pending','Portal line input lost category or unpaid state');check($o['subtotal']===Money::decimal(2*Money::parse($store->item($shop)['price'])),'Client price trusted');
    });

    test('manual website payment can collect later while online website payment remains protected',function()use($orders,$quote,$details,$online,$billing){
        $o=$orders->create($quote,$details,'website-manual-collect','web','tester');$orders->collectOnDelivery($o['id'],'tester');$o=$orders->get($o['id']);check($o['payment_mode']==='cod'&&$o['payment_status']==='cod_pending'&&$o['status']==='placed','Website manual collection missing');check(!$billing->forOrder($o['id']),'Unpaid invoice issued');
        $o=$orders->create($quote,$online,'website-online-collect','web','tester');expectError(fn()=>$orders->collectOnDelivery($o['id'],'tester'),422);expectError(fn()=>$orders->confirm($o['id'],'tester','fake',true),422);
    });
    test('explicit unpaid bill preserves balance and reuses the invoice after collection',function()use($orders,$quote,$details,$online,$billing){
        $o=$orders->create($quote,$details,'explicit-unpaid-invoice','manual','tester');$bill=$billing->issue($o['id'],true);$buyer=$bill['buyer'];
        check($orders->get($o['id'])['payment_status']==='pending','Issuing marked paid');check(!$billing->paymentState($bill)['payment_received'],'Unpaid label missing');
        check($billing->paymentState($bill)['amount_due']===$o['total'],'Wrong balance');check($billing->issue($o['id'],true)['id']===$bill['id'],'Duplicate unpaid bill');
        $orders->collectOnDelivery($o['id'],'tester');foreach(['confirmed','preparing','out_for_delivery','delivered'] as $status)$orders->advance($o['id'],$status,'tester');
        check(!$billing->paymentState($bill)['payment_received'],'Delivery settled payment');$orders->confirm($o['id'],'tester','cash-collected',true);
        $settled=$billing->issue($o['id']);check($settled['id']===$bill['id']&&$settled['number']===$bill['number']&&$settled['buyer']===$buyer,'Invoice was replaced');check($billing->paymentState($bill)['payment_received'],'Collection not reflected');
        $o=$orders->create($quote,$online,'online-unpaid-invoice-denied','web','tester');expectError(fn()=>$billing->issue($o['id'],true),422);
    });
    test('weekly meal edits preserve date menus and reservation counters and reject other stores',function()use($store,$resources,$slot,$otherSlot,$otherItem,$db,$tenant,$tomorrow){
        $id=$resources->save('dishes',null,['name'=>'Weekly editor fixture','fulfilment'=>'scheduled','price'=>'80','active'=>1,'in_stock'=>1]);
        $store->saveWeeklyMembership($id,$slot,[0,2]);
        $row=$db->one("SELECT * FROM catalog_menuschedule WHERE tenant_id=? AND item_id=? AND slot_id=? AND mode='weekday' AND weekday=0",[$tenant,$id,$slot]);$db->rows('UPDATE catalog_menuschedule SET qty_sold=3 WHERE id=?',[$row['id']]);
        $store->saveMenu($tomorrow,$slot,[$id],$store->menuRevision($tomorrow,$slot));$revision=$store->menuRevision($tomorrow,$slot);
        $store->saveWeeklyMembership($id,$slot,[2,4]);$row=$db->one('SELECT * FROM catalog_menuschedule WHERE id=?',[$row['id']]);check(!$row['available']&&(int)$row['qty_sold']===3,'Weekly reservation history lost');check($store->menuRevision($tomorrow,$slot)===$revision,'Dated menu rewritten');
        expectError(fn()=>$store->saveWeeklyMembership($id,$otherSlot,[0]),404);expectError(fn()=>$store->saveWeeklyMembership($otherItem,$slot,[0]),404);expectError(fn()=>$store->saveWeeklyMembership($id,$slot,['bad']),422);
    });
    test('all-orders category includes bookings and report ranges reject invalid calendar dates',function()use($store){
        $reports=new Annam\Reports($store);$all=$reports->orderGroups(['meal_group'=>'all']);$default=$reports->orderGroups([]);check($all['total']===$default['total']&&$all['total']>0,'All orders were filtered out');
        expectError(fn()=>$reports->data(['start'=>'2026-02-31T00:00','end'=>'2026-03-04T00:00']),422);expectError(fn()=>$reports->data(['start'=>'2026-11-20T12:00','end'=>'2026-11-20T11:00']),422);
    });
    test('refunded bills and credit notes never display an unpaid receivable',function()use($billing,$invoice,$store){
        $before=$billing->get((int)$invoice['id']);$store->update('orders_order',$before['order_id'],['payment_status'=>'refunded']);$state=$billing->paymentState($before);check($state['payment_refunded']&&!$state['payment_received']&&$state['amount_due']==='0.00','Refund labelled as outstanding');
        $credits=$store->db->rows("SELECT id FROM billing_invoice WHERE tenant_id=? AND original_id=? AND kind='credit_note'",[$store->id(),$before['id']]);check((bool)$credits,'Credit fixture missing');$credit=$billing->get((int)$credits[0]['id']);$state=$billing->paymentState($credit);check($state['amount_due']==='0.00'&&$state['settlement_reference']===$credit['payment_ref']&&$state['original_number']===$before['number'],'Credit payment metadata is misleading');check($billing->get((int)$before['id'])===$before,'Display changed immutable bill');
    });
    test('menu picker restores only explicitly selected dishes and preserves sold portions',function()use($store,$resources,$slot,$db,$tenant,$after){
        $hidden=$resources->save('dishes',null,['name'=>'Picker hidden','fulfilment'=>'scheduled','price'=>'80']);
        $stock=$resources->save('dishes',null,['name'=>'Picker stock','fulfilment'=>'scheduled','price'=>'90','active'=>1,'in_stock'=>0]);
        $untouched=$resources->save('dishes',null,['name'=>'Picker untouched','fulfilment'=>'scheduled','price'=>'100']);
        $store->saveMenu($after,$slot,[$stock],$store->menuRevision($after,$slot));
        $db->rows("UPDATE catalog_menuschedule SET qty_sold=2,qty_limit=5,price_override='85.00' WHERE tenant_id=? AND item_id=? AND slot_id=? AND on_date=?",[$tenant,$stock,$slot,$after]);
        expectError(fn()=>$store->saveMenu($after,$slot,[$hidden],$store->menuRevision($after,$slot)),422);
        $store->saveMenu($after,$slot,[$hidden,$stock],$store->menuRevision($after,$slot),[$hidden,$stock,$untouched]);
        foreach([$hidden,$stock] as $id){$item=$store->item($id);check((bool)$item['active']&&(bool)$item['in_stock'],'Chosen dish not restored');}
        check(!$store->item($untouched)['active'],'Unselected hidden dish changed');
        $rows=$store->effectiveMenuRows($after,$slot);check((int)$rows[$stock]['qty_sold']===2&&(int)$rows[$stock]['qty_limit']===5&&$rows[$stock]['price_override']==='85.00','Portions or price reset');
        check(count($store->menu($after,$slot))===2,'Restored dishes not orderable');
        $store->saveMenu($after,$slot,[],$store->menuRevision($after,$slot));check($store->item($hidden)['active']&&!$store->menu($after,$slot),'Removing from menu hid product globally');
    });
    test('menu restoration rejects stale historical foreign and shop selections atomically',function()use($store,$resources,$slot,$otherItem,$shop,$tomorrow){
        $id=$resources->save('dishes',null,['name'=>'Picker rejected','fulfilment'=>'scheduled','price'=>'80','in_stock'=>0]);
        $revision=$store->menuRevision($tomorrow,$slot);
        expectError(fn()=>$store->saveMenu($tomorrow,$slot,[$id],$revision-1,[$id]),409);
        expectError(fn()=>$store->saveMenu(date('Y-m-d',strtotime('-1 day')),$slot,[$id],0,[$id]),422);
        expectError(fn()=>$store->saveMenu($tomorrow,$slot,[$id,$otherItem],$revision,[$id,$otherItem]),404);
        expectError(fn()=>$store->saveMenu($tomorrow,$slot,[$id,$shop],$revision,[$id,$shop]),422);
        check(!$store->item($id)['active']&&!$store->item($id)['in_stock'],'Rejected save changed product');
        check($store->menuRevision($tomorrow,$slot)===$revision,'Rejected save changed menu');
    });
    test('category counts include enabled meals and shop products with matching stock filters',function()use($store,$resources,$db,$tenant,$otherItem){
        $parent=$resources->save('categories',null,['name'=>'Count meals','slug'=>'count-meals','active'=>1]);
        $child=$resources->save('categories',null,['name'=>'Count child','slug'=>'count-child','active'=>1]);
        $db->rows('UPDATE catalog_menucategory SET parent_id=? WHERE tenant_id=? AND id=?',[$parent,$tenant,$child]);
        foreach([['scheduled',1,1],['courier',1,1],['scheduled',0,1],['scheduled',1,0]] as [$kind,$active,$stock])$resources->save('dishes',null,['name'=>'Count fixture '.$kind.$active.$stock,'fulfilment'=>$kind,'price'=>'80','active'=>$active,'in_stock'=>$stock,'category_id'=>$child]);
        $routes=new Annam\ParityRoutes($store,['id'=>1],fn()=>null);$rows=$routes->categories();$row=array_values(array_filter($rows,fn($r)=>(int)$r['id']===$parent))[0];
        check($row['website']===2&&$row['total']===4,'Meals omitted or unavailable dishes included');
        $listed=$store->pageItems('','',$parent,1,30,['active'=>true,'in_stock'=>true],'');check($listed['total']===$row['website'],'Count differs from linked filtered list');
        $db->rows('UPDATE catalog_menucategory SET active=FALSE WHERE tenant_id=? AND id=?',[$tenant,$parent]);$rows=$routes->categories();$row=array_values(array_filter($rows,fn($r)=>(int)$r['id']===$parent))[0];check($row['website']===2,'Category visibility confused with product status');
    });
    test('category photos use a scoped dish without replacing saved artwork',function()use($store,$resources,$db,$tenant){
        $category=$resources->save('categories',null,['name'=>'Automatic photo','slug'=>'automatic-photo','active'=>1]);
        $item=$resources->save('dishes',null,['name'=>'Photo dish','category_id'=>$category,'fulfilment'=>'scheduled','price'=>'10','active'=>1,'in_stock'=>1]);
        $db->rows("UPDATE catalog_menuitem SET image='menu/fixture.jpg' WHERE tenant_id=? AND id=?",[$tenant,$item]);
        $row=array_values(array_filter($store->categories(),fn($c)=>(int)$c['id']===$category))[0];check($row['image']==='menu/fixture.jpg','Dish photo not used');
        check($resources->get('categories',$category)['image']==='','Fallback mutated category');
        $db->rows("UPDATE catalog_menucategory SET image='categories/original.jpg' WHERE tenant_id=? AND id=?",[$tenant,$category]);
        $row=array_values(array_filter($store->categories(),fn($c)=>(int)$c['id']===$category))[0];check($row['image']==='categories/original.jpg','Existing artwork lost');
    });
    test('repeated stock requests set the requested state without reversing it',function()use($store,$resources,$otherItem){
        $id=$resources->save('dishes',null,['name'=>'Repeated stock','fulfilment'=>'scheduled','price'=>'10','active'=>1,'in_stock'=>0]);
        $store->setItemFlag($id,'in_stock',true);$store->setItemFlag($id,'in_stock',true);check((bool)$store->item($id)['in_stock'],'Repeated enable reversed stock');
        $store->setItemFlag($id,'in_stock',false);$store->setItemFlag($id,'in_stock',false);check(!$store->item($id)['in_stock'],'Repeated disable reversed stock');
        expectError(fn()=>$store->setItemFlag($otherItem,'in_stock',true),404);expectError(fn()=>$store->setItemFlag($id,'price',true),422);
    });
    test('pending customer summaries allocate no invoice and issued unpaid bills are downloadable',function()use($store,$orders,$quote,$details,$billing,$db,$tenant){
        $order=$orders->create($quote,$details,'pending-customer-document','manual','tester');$receipt=new Annam\CustomerReceipt($store);
        $before=$db->rows('SELECT * FROM billing_invoicesequence WHERE tenant_id=?',[$tenant]);$pdf=Annam\InvoicePdf::summary($order);check(str_starts_with($pdf,'%PDF-'),'Summary is not PDF');check(!$billing->forOrder($order['id']),'Summary created financial invoice');check($before===$db->rows('SELECT * FROM billing_invoicesequence WHERE tenant_id=?',[$tenant]),'Summary consumed bill number');
        $billing->issue($order['id'],true);$state=$receipt->state($order,'fixture');check(!$state['paid']&&$state['download_url']&&$state['invoice_url'],'Issued unpaid bill hidden');check(str_starts_with($receipt->pdf($order,false),'%PDF-'),'Unpaid bill PDF missing');check($orders->get($order['id'])['payment_status']==='pending','Document marked unpaid order paid');
    });
    test('editing product details without a stock field preserves the latest saved stock value',function()use($store,$resources){
        $input=['name'=>'Persistent stock edit','fulfilment'=>'scheduled','price'=>'70','active'=>1];$id=$resources->save('dishes',null,$input+['in_stock'=>1]);
        $resources->save('dishes',$id,$input);check((bool)$store->item($id)['in_stock'],'Detail edit reset latest in-stock value');
        $store->setItemFlag($id,'in_stock',false);$resources->save('dishes',$id,$input);check(!$store->item($id)['in_stock'],'Detail edit reset latest out-of-stock value');
        $resources->save('dishes',$id,$input+['in_stock'=>1]);check((bool)$store->item($id)['in_stock'],'Explicit stock change ignored');
    });
    test('checkout offers only matching delivery areas and recalculates each selected charge',function()use($store,$resources,$slot,$tomorrow,$otherStore){
        $saved=$_SESSION['cart']??null;
        try{
            unset($_SESSION['cart']);$id=$resources->save('dishes',null,['name'=>'Area choice meal','fulfilment'=>'scheduled','price'=>'200','active'=>1,'in_stock'=>1]);$store->saveMenu($tomorrow,$slot,[$id],$store->menuRevision($tomorrow,$slot));Cart::add($store,['item_id'=>$id,'slot_id'=>$slot,'date'=>$tomorrow,'quantity'=>1]);
            $a=$resources->save('zones',null,['area_name'=>'Area A','pincode'=>'600077','delivery_fee'=>'10','min_order'=>'100','slot_keys'=>['lunch'],'active'=>1]);$b=$resources->save('zones',null,['area_name'=>'Area B','pincode'=>'600077','delivery_fee'=>'30','min_order'=>'100','slot_keys'=>['lunch'],'active'=>1]);
            $resources->save('zones',null,['area_name'=>'Hidden area','pincode'=>'600077','delivery_fee'=>'1','min_order'=>'0','slot_keys'=>['lunch'],'active'=>0]);$resources->save('zones',null,['area_name'=>'Dinner area','pincode'=>'600077','delivery_fee'=>'1','min_order'=>'0','slot_keys'=>['dinner'],'active'=>1]);
            $foreign=(new Resources($otherStore))->save('zones',null,['area_name'=>'Private area','pincode'=>'600077','delivery_fee'=>'1','min_order'=>'0','slot_keys'=>['lunch'],'active'=>1]);
            $checkout=new Annam\Checkout($store);$choices=$checkout->delivery('600077');check(count($choices['areas'])===2&&!$choices['eligible']&&$choices['fee']===null,'Ambiguous pincode auto-selected or exposed ineligible areas');
            check($checkout->delivery('600077',$a)['fee']===1000&&$checkout->delivery('600077',$b)['fee']===3000,'Area delivery charge ignored');check(!$checkout->delivery('600077',$foreign)['eligible'],'Foreign zone accepted');
            $single=$resources->save('zones',null,['area_name'=>'Only area','pincode'=>'600078','delivery_fee'=>'20','min_order'=>'100','slot_keys'=>['lunch'],'active'=>1]);$choice=$checkout->delivery('600078');check($choice['eligible']&&$choice['selected']===$single&&$choice['fee']===2000,'Single area not automatic');check(!$checkout->delivery('600078',$a)['eligible'],'Old area accepted after pincode change');check(!$checkout->delivery('123')['eligible'],'Invalid pincode accepted');
        }finally{if($saved===null)unset($_SESSION['cart']);else $_SESSION['cart']=$saved;}
    });
    test('quantity tracking defaults off and stock edits enforce revisions and exact nonnegative units',function()use($store,$resources){
        $inv=new Annam\Inventory($store);$id=$resources->save('dishes',null,['name'=>'Inventory defaults','fulfilment'=>'courier','price'=>'100','active'=>1,'in_stock'=>1]);$item=$store->item($id);check(!$item['quantity_tracked']&&!$inv->state($item)['tracked'],'New product unexpectedly limited');
        $inv->configure($id,null,null,true,20,'set',0);$state=$inv->state($item);check($state['tracked']&&(int)$state['remaining']===20,'Initial quantity not saved');$inv->configure($id,null,null,true,5,'add',(int)$state['revision']);check((int)$inv->state($item)['remaining']===25,'Restock replaced instead of adding');
        expectError(fn()=>$inv->configure($id,null,null,true,2,'set',0),409);$state=$inv->state($item);expectError(fn()=>$inv->configure($id,null,null,true,-1,'set',(int)$state['revision']),422);expectError(fn()=>$inv->configure($id,null,null,true,'1.5','set',(int)$state['revision']),422);check((int)$inv->state($item)['remaining']===25,'Invalid edit changed stock');
        $inv->configure($id,null,null,false,null,'set',(int)$state['revision']);check(!$inv->state($item)['tracked']&&(int)$inv->state($item)['remaining']===25,'Disabling deleted stock');
    });
    test('manual billing reserves unpaid stock once and payment and invoices never deduct twice',function()use($store,$resources,$orders,$billing){
        $inv=new Annam\Inventory($store);$id=$resources->save('dishes',null,['name'=>'Inventory manual product','fulfilment'=>'courier','price'=>'100','active'=>1,'in_stock'=>1]);$inv->configure($id,null,null,true,10,'set',0);$item=$store->item($id);
        $token=bin2hex(random_bytes(16));$_SESSION['staff_tokens'][$token]=time();$input=['name'=>'Inventory manual','phone'=>'919876543210','token'=>$token,'payment_method'=>'manual','booking_lines'=>[['item'=>$id,'quantity'=>3,'meal'=>'snacks']]];$o=$orders->staff($input,'tester');check($o['payment_status']==='pending'&&(int)$inv->state($item)['remaining']===7,'Unpaid manual bill did not reserve');check($orders->staff($input,'tester')['id']===$o['id']&&(int)$inv->state($item)['remaining']===7,'Retry deducted twice');
        $orders->confirm($o['id'],'tester','cash',true);$billing->issue($o['id']);$inv->reserve($o['id'],['lines'=>[]],'manual');check((int)$inv->state($item)['remaining']===7,'Payment or bill deducted again');
        $orders->advance($o['id'],'cancelled','tester');$orders->advance($o['id'],'cancelled','tester');$inv->release($o['id']);check((int)$inv->state($item)['remaining']===10,'Cancellation did not restore exactly once');
    });
    test('mixed manual bill stock failure rolls back earlier deductions and the new order',function()use($store,$resources,$orders,$db,$tenant){
        $inv=new Annam\Inventory($store);$ids=[];foreach([5,1] as $n){$id=$resources->save('dishes',null,['name'=>'Inventory atomic '.$n,'fulfilment'=>'courier','price'=>'100','active'=>1,'in_stock'=>1]);$inv->configure($id,null,null,true,$n,'set',0);$ids[]=$id;}
        $token=bin2hex(random_bytes(16));$_SESSION['staff_tokens'][$token]=time();$before=(int)$db->one('SELECT COUNT(*) AS n FROM orders_order WHERE tenant_id=?',[$tenant])['n'];$input=['name'=>'Inventory atomic','phone'=>'919876543211','token'=>$token,'payment_method'=>'cod','booking_lines'=>[['item'=>$ids[0],'quantity'=>2,'meal'=>'snacks'],['item'=>$ids[1],'quantity'=>2,'meal'=>'snacks']]];expectError(fn()=>$orders->staff($input,'tester'),409);
        check((int)$inv->state($store->item($ids[0]))['remaining']===5&&(int)$inv->state($store->item($ids[1]))['remaining']===1,'Failed bill partially deducted');check((int)$db->one('SELECT COUNT(*) AS n FROM orders_order WHERE tenant_id=?',[$tenant])['n']===$before,'Failed bill left an order');
    });
    test('website and manual meal orders share dated stock and preserve historical sold counters',function()use($store,$resources,$orders,$slot,$tomorrow,$after,$details,$db,$tenant){
        $saved=$_SESSION['cart']??null;$inv=new Annam\Inventory($store);$id=$resources->save('dishes',null,['name'=>'Inventory dated meal','fulfilment'=>'scheduled','price'=>'200','active'=>1,'in_stock'=>1]);$store->saveMenu($tomorrow,$slot,[$id],$store->menuRevision($tomorrow,$slot));$db->rows("UPDATE catalog_menuschedule SET qty_sold=4 WHERE tenant_id=? AND item_id=? AND slot_id=? AND mode='date' AND on_date=?",[$tenant,$id,$slot,$tomorrow]);$inv->configure($id,$tomorrow,$slot,true,20,'set',0);$item=$store->item($id);
        try{unset($_SESSION['cart']);Cart::add($store,['item_id'=>$id,'slot_id'=>$slot,'date'=>$tomorrow,'quantity'=>3]);check((int)$inv->state($item,$tomorrow,$slot)['remaining']===20,'Adding to cart reserved stock');$q=(new Annam\Checkout($store))->quote($_SESSION['cart'],$details);$o=$orders->create($q,$details,'inventory-web-meal','web');check((int)$inv->state($item,$tomorrow,$slot)['remaining']===17,'Web meal stock not reduced');expectError(fn()=>$inv->configure($id,$tomorrow,$slot,true,20,'set',1),409);
            $token=bin2hex(random_bytes(16));$_SESSION['staff_tokens'][$token]=time();$m=$orders->staff(['name'=>'Meal manual','phone'=>'919876543212','token'=>$token,'delivery_date'=>$tomorrow,'booking_lines'=>[['item'=>$id,'quantity'=>2,'meal'=>'lunch']]],'tester');check((int)$inv->state($item,$tomorrow,$slot)['remaining']===15,'Manual and web stock not shared');check(!$inv->state($item,$after,$slot)['tracked'],'Quantity tracking leaked to another date');
            $orders->advance($o['id'],'cancelled','tester');$orders->advance($m['id'],'cancelled','tester');check((int)$inv->state($item,$tomorrow,$slot)['remaining']===20,'Dated cancellation restoration failed');$row=$store->effectiveMenuRows($tomorrow,$slot)[$id];check((int)$row['qty_sold']===4,'Historical sold counter changed');
            $inv->configure($id,date('Y-m-d'),$slot,true,8,'set',0);$token=bin2hex(random_bytes(16));$_SESSION['staff_tokens'][$token]=time();$m=$orders->staff(['name'=>'Today manual','phone'=>'919876543213','token'=>$token,'booking_lines'=>[['item'=>$id,'quantity'=>2,'meal'=>'lunch']]],'tester');check((int)$inv->state($item,date('Y-m-d'),$slot)['remaining']===6&&(int)$inv->state($item,$tomorrow,$slot)['remaining']===20,'Blank billing date did not use today independently');$orders->advance($m['id'],'cancelled','tester');
        }finally{if($saved===null)unset($_SESSION['cart']);else $_SESSION['cart']=$saved;}
    });
    test('zero tracked stock blocks website carts and staff billing until stock is added',function()use($store,$resources,$orders){
        $inv=new Annam\Inventory($store);$id=$resources->save('dishes',null,['name'=>'Inventory zero','fulfilment'=>'courier','price'=>'100','active'=>1,'in_stock'=>1]);$inv->configure($id,null,null,true,0,'set',0);$item=$store->item($id);expectError(fn()=>Cart::add($store,['item_id'=>$id,'quantity'=>1]),422);
        $token=bin2hex(random_bytes(16));$_SESSION['staff_tokens'][$token]=time();expectError(fn()=>$orders->staff(['name'=>'Zero stock','phone'=>'919876543214','token'=>$token,'quantities'=>[$id=>1]],'tester'),409);check($store->pageItems('courier','Inventory zero',null,1,30,['in_stock'=>true])['total']===0,'Exhausted product still counted in stock');
        $inv->configure($id,null,null,true,5,'add',(int)$inv->state($item)['revision']);check($store->pageItems('courier','Inventory zero',null,1,30,['in_stock'=>true])['total']===1,'Restocked product stayed unavailable');
    });
    test('inventory settings cannot edit another store and do not rewrite past meal stock',function()use($store,$resources,$otherItem,$otherSlot,$slot){
        $inv=new Annam\Inventory($store);expectError(fn()=>$inv->configure($otherItem,null,null,true,5,'set',0),404);$id=$resources->save('dishes',null,['name'=>'Inventory scope','fulfilment'=>'scheduled','price'=>'100','active'=>1,'in_stock'=>1]);expectError(fn()=>$inv->configure($id,date('Y-m-d'),$otherSlot,true,5,'set',0),404);expectError(fn()=>$inv->configure($id,date('Y-m-d',strtotime('-1 day')),$slot,true,5,'set',0),422);
    });
    test('category deletion preserves products stock and child categories and rejects another store',function()use($store,$resources,$other){
        $parent=$resources->save('categories',null,['name'=>'Delete fixture','slug'=>'delete-fixture','active'=>1]);
        $child=$resources->save('categories',null,['name'=>'Kept child','slug'=>'kept-child','active'=>1]);
        $store->db->rows('UPDATE catalog_menucategory SET parent_id=? WHERE tenant_id=? AND id=?',[$parent,$store->id(),$child]);
        $item=$resources->save('dishes',null,['name'=>'Kept product','fulfilment'=>'courier','price'=>'125','category_id'=>$parent,'active'=>1,'in_stock'=>1]);
        $inv=new Annam\Inventory($store);$inv->configure($item,null,null,true,9,'set',0);
        $foreign=insert($store->db,'catalog_menucategory',['tenant_id'=>$other,'name'=>'Foreign category','slug'=>'foreign-delete','description'=>'','image'=>'','sort'=>0,'active'=>true,'parent_id'=>null]);
        expectError(fn()=>$resources->deleteCategory($foreign),404);
        $resources->deleteCategory($parent);expectError(fn()=>$resources->get('categories',$parent),404);
        $saved=$store->item($item);check($saved['category_id']===null&&$saved['in_stock']&&$saved['stock_quantity']===9,'Product or stock lost');
        check($resources->get('categories',$child)['parent_id']===null,'Child category lost');
        check($store->db->one('SELECT id FROM catalog_menucategory WHERE tenant_id=? AND id=?',[$other,$foreign])!==null,'Foreign category changed');
    });
    test('recent cart order shows the latest owned order and never another browser',function()use($store,$resources){
        $session=$_SESSION;$cookies=$_COOKIE;try{
            $_COOKIE=[];$_SESSION=['checkout_browser'=>bin2hex(random_bytes(16))];$key=$_SESSION['checkout_browser'];$checkout=new Annam\Checkout($store);$orders=new Annam\Orders($store);
            $item=$resources->save('dishes',null,['name'=>'Recent order product','price'=>'120','fulfilment'=>'courier','active'=>1,'in_stock'=>1]);
            $quote=Annam\Pricing::totals([Annam\Pricing::line($store->item($item),1)],0,$store->profile())+['kind'=>'courier','zone'=>[]];$details=['name'=>'Recent customer','phone'=>'9876543219','payment_method'=>'manual','line1'=>'Test street','city'=>'Chennai','pincode'=>'600005'];
            check($checkout->recentOrder()===null,'New browser saw an order');
            $first=bin2hex(random_bytes(16));$orders->create($quote,$details,'web:'.$key.':'.$first);$last=bin2hex(random_bytes(16));$order=$orders->create($quote,$details,'web:'.$key.':'.$last);
            $orders->create($quote,$details,'web:'.bin2hex(random_bytes(16)).':'.bin2hex(random_bytes(16)));
            $recent=$checkout->recentOrder();check($recent['reference']===$last&&$recent['order']['id']===$order['id'],'Latest owned order was not shown');
            $_SESSION=['checkout_browser'=>bin2hex(random_bytes(16))];check($checkout->recentOrder()===null,'Other browser saw recent order');expectError(fn()=>$checkout->guest($last),404);
        }finally{$_SESSION=$session;$_COOKIE=$cookies;}
    });
    test('four starter categories are created once and permit custom categories',function()use($store,$resources){
        $catalog=new Annam\Catalog($store);$catalog->defaults();$before=$store->db->rows('SELECT id,slug FROM catalog_menucategory WHERE tenant_id=? ORDER BY id',[$store->id()]);$catalog->defaults();check($before===$store->db->rows('SELECT id,slug FROM catalog_menucategory WHERE tenant_id=? ORDER BY id',[$store->id()]),'Defaults duplicated');
        foreach(Annam\Catalog::DEFAULTS as $key=>$name)check($store->db->one('SELECT id FROM catalog_menucategory WHERE tenant_id=? AND slug=?',[$store->id(),$key])!==null,'Default category missing');
        $custom=$resources->save('categories',null,['name'=>'Extra category','slug'=>'extra-category','active'=>1]);check($resources->get('categories',$custom)['name']==='Extra category','Custom categories blocked');
    });
    test('one dish belongs to all three meal libraries without publishing a daily menu',function()use($store,$resources){
        $catalog=new Annam\Catalog($store);$catalog->defaults();$id=$resources->save('dishes',null,['name'=>'Shared meal library dish','price'=>'90','fulfilment'=>'scheduled','active'=>1,'in_stock'=>1]);$catalog->assign($id,['breakfast','lunch','dinner']);
        check($catalog->meals($store->item($id))===['breakfast','lunch','dinner'],'Multi-meal assignment lost');
        foreach(Annam\Catalog::MEALS as $key=>$label){check($store->pageItems('scheduled','Shared meal library dish',null,1,10,[],$key)['total']===1,'Dish missing in meal library');$slot=$store->db->one('SELECT id FROM catalog_slot WHERE tenant_id=? AND key=?',[$store->id(),$key]);check(!in_array($id,array_column($store->menu(date('Y-m-d',strtotime('+2 days')),(int)$slot['id']),'id')),'Catalog assignment published dish');}
        check(!$store->db->one('SELECT id FROM catalog_menuschedule WHERE tenant_id=? AND item_id=?',[$store->id(),$id]),'Assignment rewrote schedules');
    });
    test('meal library changes preserve saved menus stock and other item tags',function()use($store,$resources,$slot){
        $catalog=new Annam\Catalog($store);$id=$resources->save('dishes',null,['name'=>'Keep daily selection','price'=>'90','fulfilment'=>'scheduled','active'=>1,'in_stock'=>1,'featured'=>1]);$catalog->assign($id,['lunch','dinner']);$date=date('Y-m-d',strtotime('+3 days'));$store->saveMenu($date,$slot,[$id],$store->menuRevision($date,$slot));$before=$store->db->rows('SELECT * FROM catalog_menuschedule WHERE tenant_id=? AND item_id=?',[$store->id(),$id]);$catalog->assign($id,['breakfast']);check($before===$store->db->rows('SELECT * FROM catalog_menuschedule WHERE tenant_id=? AND item_id=?',[$store->id(),$id]),'Saved menus changed');check(in_array('featured',json_decode($store->item($id)['tags'],true),true),'Other tags lost');check($store->pageItems('scheduled','Keep daily selection',null,1,10,[],'lunch')['total']===0,'Old dated schedule overrode explicit library membership');
    });
    test('shop products use Shop and invalid or foreign meal assignments are rejected',function()use($store,$resources,$otherItem){
        $catalog=new Annam\Catalog($store);$id=$resources->save('dishes',null,['name'=>'Shop starter item','price'=>'90','fulfilment'=>'courier','active'=>1,'in_stock'=>1]);$catalog->assign($id,[]);$item=$store->item($id);$category=$resources->get('categories',(int)$item['category_id']);check($category['slug']==='shop'&&$catalog->meals($item)===[],'Shop defaults incorrect');expectError(fn()=>$catalog->assign($otherItem,['breakfast']),404);expectError(fn()=>$catalog->assign($id,[['lunch']]),422);
    });
    Annam\Http::$transport=null;
    echo "$passed behavioural tests passed. All fixture records rolled back.\n";
} finally { $pdo->rollBack(); }
