<?php
declare(strict_types=1);
require dirname(__DIR__).'/annam-private/src/bootstrap.php';
\Annam\Application::run();
